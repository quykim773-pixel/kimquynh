# -*- coding: utf-8 -*-
"""
HAKURA2 KEY MANAGEMENT ENGINE
=============================
Quản lý License Key cho Web API (Visit, Team5, SpamKB)
- Hạn dùng (ngày hoặc vĩnh viễn)
- Giới hạn thiết bị / IP truy cập
- Phân quyền Admin Telegram ID: 6623644211
"""

import os
import json
import time
import random
import string
import threading

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
KEYS_FILE = os.path.join(BASE_DIR, "keys.json")
KEYS_LOCK = threading.Lock()

ADMIN_ID = 6623644211


def load_keys() -> dict:
    if not os.path.exists(KEYS_FILE):
        return {}
    try:
        with open(KEYS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[load_keys error]: {e}")
        return {}


def save_keys(data: dict) -> bool:
    try:
        with open(KEYS_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"[save_keys error]: {e}")
        return False


def generate_random_key(prefix: str = "VIP") -> str:
    part1 = "".join(random.choices(string.ascii_uppercase + string.digits, k=4))
    part2 = "".join(random.choices(string.ascii_uppercase + string.digits, k=4))
    return f"{prefix}-{part1}-{part2}"


def create_key(days: int = 0, device_limit: int = 1, is_permanent: bool = False, created_by: int = ADMIN_ID, custom_key: str = None) -> dict:
    with KEYS_LOCK:
        keys = load_keys()
        key_str = custom_key.strip() if custom_key else generate_random_key()
        now = time.time()
        
        if is_permanent or days <= 0:
            expires_at = None
            is_perm = True
        else:
            expires_at = now + (days * 86400)
            is_perm = False

        record = {
            "key": key_str,
            "created_at": now,
            "expires_at": expires_at,
            "is_permanent": is_perm,
            "device_limit": max(1, int(device_limit)),
            "used_devices": [],
            "created_by": created_by
        }
        keys[key_str] = record
        save_keys(keys)
        return record


def delete_key(key: str) -> bool:
    with KEYS_LOCK:
        keys = load_keys()
        if key in keys:
            del keys[key]
            save_keys(keys)
            return True
        return False


def validate_key(key_str: str, device_id: str = None) -> tuple[bool, str, dict | None]:
    """
    Kiểm tra tính hợp lệ của Key:
    - Tồn tại
    - Hạn dùng
    - Giới hạn thiết bị / IP
    """
    if not key_str:
        return False, "Thiếu tham số key!", None
    
    clean_k = key_str.strip()
    with KEYS_LOCK:
        keys = load_keys()
        if clean_k not in keys:
            return False, "Key không tồn tại hoặc đã bị xóa!", None

        k_data = keys[clean_k]
        now = time.time()

        # 1. Kiểm tra hạn dùng
        if not k_data.get("is_permanent"):
            exp = k_data.get("expires_at")
            if exp and now > exp:
                return False, "Key đã hết hạn sử dụng!", k_data

        # 2. Kiểm tra giới hạn thiết bị (IP / HWID)
        dev_lim = k_data.get("device_limit", 1)
        used_devs = k_data.get("used_devices", [])

        if device_id:
            dev_str = str(device_id).strip()
            if dev_str not in used_devs:
                if len(used_devs) >= dev_lim:
                    return False, f"Key đã đạt tối đa số thiết bị ({len(used_devs)}/{dev_lim})!", k_data
                used_devs.append(dev_str)
                k_data["used_devices"] = used_devs
                keys[clean_k] = k_data
                save_keys(keys)

        return True, "Key hợp lệ", k_data


def list_keys() -> list[dict]:
    keys = load_keys()
    return list(keys.values())


def format_key_info(k: dict) -> str:
    now = time.time()
    k_name = k.get("key", "N/A")
    dev_lim = k.get("device_limit", 1)
    used = len(k.get("used_devices", []))
    
    if k.get("is_permanent"):
        exp_str = "Vĩnh viễn (Không thời hạn)"
        status = "🟢 Hoạt động"
    else:
        exp = k.get("expires_at", 0)
        if exp < now:
            exp_str = time.strftime("%d/%m/%Y %H:%M", time.localtime(exp))
            status = "🔴 Đã hết hạn"
        else:
            remain_days = round((exp - now) / 86400, 1)
            exp_str = f"{time.strftime('%d/%m/%Y %H:%M', time.localtime(exp))} (Còn {remain_days} ngày)"
            status = "🟢 Hoạt động"

    return (
        f"🔑 **Key:** `{k_name}`\n"
        f"   • Trạng thái: {status}\n"
        f"   • Hạn dùng: {exp_str}\n"
        f"   • Thiết bị: `{used}/{dev_lim}` đã liên kết\n"
    )
