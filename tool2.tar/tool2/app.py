# ═══════════════════════════════════════════════════════════════
# Dev: @Jamiulgaming1 | TG: https://t.me/Jamiulgaming1
# ═══════════════════════════════════════════════════════════════

import os
import threading
import asyncio
import base64
import zlib
import json
import requests

from flask import Flask, jsonify, request
from cfonts import render

import login_engine
import bot_core
import key_manager
from ff_core import send_visit_all, spam_friend_requests_all, query_player_profile
from bot_core import (
    TcPOnLine,
    TcPChaT,
    build_ob55_online_auth,
    create_auth_token_chat,
)

# ─── Config ───
PORT = int(os.environ.get("PORT", 10000))

UID         = os.environ.get("GUEST_UID", "7174307523")
PW          = os.environ.get(
    "GUEST_PW",
    "E128D744077B8739D5D310EB66427B4F8507C6E871272869158B30D6A75DB77D",
)
REGION_PREF = os.environ.get("REGION", "VN")

app = Flask(__name__)

BOT_SESSION = {
    "loop": None,
    "bot_uid": None,
    "key": None,
    "iv": None,
    "region": None,
    "name": None
}

_ENCRYPTED_BANNER = "eJwVzMEJwjAQRNFe9jzF9wQJ2YDeQdJeQhJnY4ySXn8S5vBg3sx8Zw/P5R6Vx2xT29lr6CzVrZZMXKOlGUdsxAXVlLqQWadKccyt0u4ibZaVf/CyEKVZpOnU2NoQOxA8RjW7n9E6hSJz0kl1XKvvK0TdMj/HUmsZMOaMzCkU+1oWWaDzhS3fXlO5NpG3b/Fz7R8=" 
def _get_banner():
    try:
        return zlib.decompress(base64.b64decode(_ENCRYPTED_BANNER)).decode('utf-8')
    except:
        return "JAMIUL GAMING"

# ───────────────────────────────────────────────────────────────
# Bot Core
# ───────────────────────────────────────────────────────────────
async def _auto_accept_friend_loop():
    """Tự động kiểm tra và chấp nhận kết bạn liên tục trong nền"""
    while True:
        try:
            await asyncio.sleep(4)
            target_uid = 15162700166
            if BOT_SESSION.get("bot_uid"):
                from ff_core import get_all_cached_sessions, pb_field, encrypt_aes
                sessions = get_all_cached_sessions()
                for s in sessions[:2]:
                    tok = s.get("token")
                    s_url = s.get("server_url", "https://clientbp.ppmainecoonghj.com").rstrip("/")
                    hdrs = {
                        "Authorization": f"Bearer {tok}",
                        "X-Unity-Version": "2018.4.12f1",
                        "X-GA": "v1 1",
                        "ReleaseVersion": "OB55",
                        "Content-Type": "application/x-www-form-urlencoded"
                    }
                    p = encrypt_aes(pb_field(1, int(target_uid)))
                    r = requests.post(f"{s_url}/ConfirmFriendRequest", data=p, headers=hdrs, timeout=4)
                    if r.status_code == 200:
                        print(f"[+] 🎉 AUTO-ACCEPTED friend request from {target_uid} on {s.get('name')}!")
        except Exception:
            pass


async def MaiiiinE():
    """Login + TCP start"""
    global BOT_SESSION
    print("[*] Starting login...")
    result = None
    if os.path.exists("accounts.json"):
        with open("accounts.json", "r", encoding="utf-8") as f:
            acc_list = json.load(f)
        for a in acc_list:
            u = str(a.get("uid"))
            p = str(a.get("password"))
            try:
                res = await login_engine.do_login(u, p, REGION_PREF)
                if res and res.get("token"):
                    result = res
                    break
            except Exception:
                continue

    if not result:
        result = await login_engine.do_login(UID, PW, REGION_PREF)

    if not result:
        print("[-] Login failed, retry in 10s...")
        await asyncio.sleep(10)
        return

    bot_core.bot_uid = result["bot_uid"]
    bot_core.ToKen   = result["token"]
    bot_core.region  = result["region"]

    key       = result["key"]
    iv        = result["iv"]
    timestamp = result["timestamp"]
    online_ip = result["online_ip"]
    online_port = result["online_port"]
    chat_ip   = result["chat_ip"]
    chat_port = result["chat_port"]
    acc_name  = result["account_name"]

    BOT_SESSION["loop"] = asyncio.get_running_loop()
    BOT_SESSION["bot_uid"] = int(result["bot_uid"])
    BOT_SESSION["key"] = key
    BOT_SESSION["iv"] = iv
    BOT_SESSION["region"] = result["region"]
    BOT_SESSION["name"] = acc_name

    print(f"[+] UID: {result['bot_uid']} | Region: {result['region']} | Name: {acc_name}")

    # Auth tokens
    ChatAutH = create_auth_token_chat(
        int(result["bot_uid"]), result["token"], int(timestamp), key, iv
    )
    OnlineAutH, _ = build_ob55_online_auth(
        int(result["bot_uid"]), result["token"], int(timestamp), key, iv
    )

    # TCP tasks start
    ready_event = asyncio.Event()
    asyncio.create_task(_auto_accept_friend_loop())
    t1 = asyncio.create_task(
        TcPChaT(chat_ip, chat_port, ChatAutH, key, iv, ready_event, result["region"])
    )
    await ready_event.wait()
    await asyncio.sleep(1)
    t2 = asyncio.create_task(
        TcPOnLine(online_ip, online_port, key, iv, OnlineAutH)
    )

    print("\n")
    try:
        banner_text = _get_banner()
        print(render(banner_text, colors=['red', 'yellow'], align='center'))
    except Exception:
        print("====== JAMIUL GAMING TCP ======")

    print(f" - Region => {result['region']}")
    print(f" - Bot Online! UID: {result['bot_uid']} | Name: {acc_name}")
    print(f" - Dev: @Jamiulgaming1 | TG: https://t.me/Jamiulgaming1\n")

    await asyncio.gather(t1, t2)


async def StarTinG():
    """Auto-restart loop"""
    while True:
        try:
            await asyncio.wait_for(MaiiiinE(), timeout=7 * 60 * 60)
        except asyncio.TimeoutError:
            print("[!] Token expired, restarting...")
        except asyncio.CancelledError:
            print("[!] Bot loop cancelled, exiting...")
            raise
        except Exception as e:
            print(f"[!] Error: {e} -> Restarting in 5s...")
            await asyncio.sleep(5)


# ───────────────────────────────────────────────────────────────
# ───────────────────────────────────────────────────────────────
# Flask API Routes for Telegram Bot Control
# ───────────────────────────────────────────────────────────────
async def _send_online_packet(pkt):
    if not pkt:
        return False
    writer = getattr(bot_core, 'online_writer', None) or bot_core.TcPOnLine.__globals__.get('online_writer')
    if not writer or writer.is_closing():
        print("[-] _send_online_packet: online_writer is None or closing")
        return False
    try:
        await bot_core.SEndPacKeT(writer, bot_core.whisper_writer, 'OnLine', pkt)
        return True
    except Exception as e:
        print(f"[*] Fallback direct write due to SEndPacKeT: {e}")
        try:
            writer.write(pkt)
            await writer.drain()
            return True
        except Exception as e2:
            print(f"[-] Direct write failed: {e2}")
            return False


async def _async_create_team5():
    try:
        g = bot_core.TcPOnLine.__globals__
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        g['pending_ghost_future'] = fut
        g['ghost_squad_code'] = None

        # 0. Exit previous squad if bot is already in one
        try:
            exit_pkt = await bot_core.ExiT(int(BOT_SESSION["bot_uid"]), BOT_SESSION["key"], BOT_SESSION["iv"])
            await _send_online_packet(exit_pkt)
            await asyncio.sleep(0.3)
        except Exception as e:
            print(f"[*] Exit before team5 notice: {e}")

        # 1. Create squad packet
        pkt_create = await bot_core.CreateNewSquad(BOT_SESSION["key"], BOT_SESSION["iv"], BOT_SESSION["region"])
        sent1 = await _send_online_packet(pkt_create)
        print(f"[+] Sent CreateNewSquad packet: {sent1} ({len(pkt_create)} bytes)")
        await asyncio.sleep(0.5)

        # 2. Expand to 5-man squad
        pkt_team5 = await bot_core.ChangeSquadTo5(BOT_SESSION["bot_uid"], BOT_SESSION["key"], BOT_SESSION["iv"], BOT_SESSION["region"])
        sent2 = await _send_online_packet(pkt_team5)
        print(f"[+] Sent ChangeSquadTo5 packet: {sent2} ({len(pkt_team5)} bytes)")

        try:
            await asyncio.wait_for(fut, timeout=7.0)
            print("[+] Garena returned squad response!")
        except Exception:
            pass

        code = g.get('ghost_squad_code') or getattr(bot_core, 'ghost_squad_code', None)
        return str(code) if code else None
    except Exception as e:
        print(f"[_async_create_team5 error]: {e}")
        return None


async def _build_join_squad_packet(team_code, key, iv, region="VN"):
    reg = str(region).upper() if region else "VN"
    hh = {
        1: 4,
        2: {
            4: bytes.fromhex("01090a0b121920"),
            5: str(team_code),
            6: 6,
            8: 1,
            9: {
                2: 800,
                4: "w^_R",
                6: 11,
                7: "\u0014\u0004aqrg\u0015\u0013",
                8: "1.132.13",
                9: 5,
                10: 1
            },
            11: {
                1: "IDC4",
                2: 281,
                3: str(reg)
            },
            13: "vi" if reg == "VN" else "en",
            16: "7OR\u0019",
            20: "\b\u0015",
            27: "\bH\u0010\u0003"
        }
    }
    proto_bytes = await bot_core.CrEaTe_ProTo(hh)
    return await bot_core.GeneRaTePk(proto_bytes.hex(), '0515', key, iv)


async def _async_join_squad(digits):
    try:
        pkt_join = await _build_join_squad_packet(str(digits), BOT_SESSION["key"], BOT_SESSION["iv"], BOT_SESSION.get("region", "VN"))
        sent = await _send_online_packet(pkt_join)
        print(f"[+] Sent real OB55 JoinSq packet for team {digits}: {sent} ({len(pkt_join)} bytes)")
        return bool(sent)
    except Exception as e:
        print(f"[_async_join_squad error]: {e}")
        try:
            pkt_fallback = bot_core.JoinSq(str(digits), BOT_SESSION["key"], BOT_SESSION["iv"])
            return await _send_online_packet(pkt_fallback)
        except Exception as e2:
            print(f"[_async_join_squad fallback error]: {e2}")
            return False


@app.route("/")
def home():
    return jsonify({
        "status": "active",
        "service": "HAKURA2 Web API Engine",
        "auth_mode": "key_required",
        "bot_uid": BOT_SESSION.get("bot_uid"),
        "name": BOT_SESSION.get("name"),
        "region": BOT_SESSION.get("region"),
        "squad_code": getattr(bot_core, 'ghost_squad_code', None),
        "api_endpoints": {
            "visit": "/api?visit={uid}&key={key}",
            "team5": "/api?team5={uid}&key={key}",
            "spamkb": "/api?spamkb={uid}&key={key}"
        },
        "note": "Hệ thống yêu cầu Key bản quyền hợp lệ. Tạo key trên Telegram Bot qua lệnh /taokey (Admin 6623644211)."
    })


@app.route("/healthz")
def healthz():
    return jsonify({"status": "ok"}), 200


# ───────────────────────────────────────────────────────────────
# KEY VALIDATION & WEB API JSON (Visit, Team5, SpamKB)
# ───────────────────────────────────────────────────────────────
PUBLIC_MODE = False  # BẮT BUỘC PHẢI CÓ KEY BẢN QUYỀN HỢP LỆ

@app.after_request
def after_request(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type,Authorization"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response


def _get_client_ip():
    if request.headers.get("X-Forwarded-For"):
        return request.headers.get("X-Forwarded-For").split(",")[0].strip()
    return request.remote_addr or "127.0.0.1"


def _validate_request_key():
    # Khi PUBLIC_MODE = False, bắt buộc phải có key hợp lệ
    if PUBLIC_MODE:
        return True, "Chế độ Public công khai", None

    key = (
        request.args.get("key")
        or (request.json.get("key") if request.is_json else None)
        or request.form.get("key")
    )
    if not key:
        return False, "Thiếu tham số key bản quyền!", None
    client_ip = _get_client_ip()
    ok, msg, k_data = key_manager.validate_key(key, client_ip)
    return ok, msg, k_data


def _handle_visit_api(target_uid):
    if not target_uid:
        return jsonify({"status": "error", "code": 400, "msg": "Thiếu tham số UID người chơi!"}), 400
    clean_uid = "".join(filter(str.isdigit, str(target_uid)))
    if not clean_uid:
        return jsonify({"status": "error", "code": 400, "msg": "UID người chơi không hợp lệ!"}), 400

    result = send_visit_all(clean_uid)
    total_ok = result.get("total_success", 0)
    total_att = result.get("total_attempted", 0)

    return jsonify({
        "status": "success" if total_ok > 0 else "failed",
        "action": "visit",
        "target_uid": clean_uid,
        "total_success": total_ok,
        "total_attempted": total_att,
        "msg": f"Đã gửi thành công {total_ok}/{total_att} lượt ghé thăm tới UID {clean_uid}!"
    })


def _handle_spamkb_api(target_uid):
    if not target_uid:
        return jsonify({"status": "error", "code": 400, "msg": "Thiếu tham số UID người chơi!"}), 400
    clean_uid = "".join(filter(str.isdigit, str(target_uid)))
    if not clean_uid:
        return jsonify({"status": "error", "code": 400, "msg": "UID người chơi không hợp lệ!"}), 400

    result = spam_friend_requests_all(clean_uid)
    total_ok = result.get("total_success", 0)
    total_att = result.get("total_attempted", 0)

    return jsonify({
        "status": "success" if total_ok > 0 else "failed",
        "action": "spamkb",
        "target_uid": clean_uid,
        "total_success": total_ok,
        "total_attempted": total_att,
        "msg": f"Đã gửi thành công {total_ok}/{total_att} lời mời kết bạn tới UID {clean_uid}!"
    })


def _handle_team5_api(target_uid):
    if not target_uid:
        return jsonify({"status": "error", "code": 400, "msg": "Thiếu tham số UID người chơi!"}), 400
    clean_uid = "".join(filter(str.isdigit, str(target_uid)))
    if not clean_uid:
        return jsonify({"status": "error", "code": 400, "msg": "UID người chơi không hợp lệ!"}), 400
    if not BOT_SESSION["loop"] or not BOT_SESSION["bot_uid"]:
        return jsonify({"status": "error", "code": 400, "msg": "Bot chưa online trong sảnh!"}), 400

    future = asyncio.run_coroutine_threadsafe(_async_create_team5(), BOT_SESSION["loop"])
    try:
        team_code = future.result(timeout=8.0)
    except Exception:
        team_code = None

    target_int = int(clean_uid)
    async def _send_team5_invite():
        try:
            await asyncio.sleep(0.4)
            pkt = await bot_core.SendInvite(target_int, BOT_SESSION["key"], BOT_SESSION["iv"], BOT_SESSION.get("region", "VN"))
            await _send_online_packet(pkt)
            await asyncio.sleep(0.8)
            await _send_online_packet(pkt)
        except Exception as e:
            print(f"[_send_team5_invite error]: {e}")
    asyncio.run_coroutine_threadsafe(_send_team5_invite(), BOT_SESSION["loop"])

    return jsonify({
        "status": "success",
        "action": "team5",
        "target_uid": clean_uid,
        "team_code": str(team_code) if team_code else None,
        "bot_name": BOT_SESSION.get("name"),
        "bot_uid": BOT_SESSION.get("bot_uid"),
        "msg": f"Đã tạo sảnh Team 5 thành công và gửi lời mời in-game tới UID {clean_uid}!"
    })


@app.route("/api", methods=["GET", "POST"])
def unified_api():
    ok, err_msg, k_data = _validate_request_key()
    if not ok:
        return jsonify({"status": "error", "code": 403, "msg": err_msg}), 403

    # 1. Visit: ?visit={uid}&key={key}
    if "visit" in request.args or (request.is_json and "visit" in request.json):
        uid = request.args.get("visit") or (request.json.get("visit") if request.is_json else None)
        return _handle_visit_api(uid)

    # 2. Team5: ?team5={uid}&key={key}
    if "team5" in request.args or (request.is_json and "team5" in request.json):
        uid = request.args.get("team5") or (request.json.get("team5") if request.is_json else None)
        return _handle_team5_api(uid)

    # 3. SpamKB: ?spamkb={uid}&key={key}
    if "spamkb" in request.args or (request.is_json and "spamkb" in request.json):
        uid = request.args.get("spamkb") or (request.json.get("spamkb") if request.is_json else None)
        return _handle_spamkb_api(uid)

    return jsonify({
        "status": "info",
        "service": "HAKURA2 Web API Engine",
        "auth_required": True,
        "usage": {
            "visit": "/api?visit={uid}&key={key}",
            "team5": "/api?team5={uid}&key={key}",
            "spamkb": "/api?spamkb={uid}&key={key}"
        },
        "note": "Bắt buộc phải có tham số key bản quyền hợp lệ. Liên hệ Admin Telegram 6623644211 để được cấp key."
    })


@app.route("/api/visit", methods=["GET", "POST"])
@app.route("/visit", methods=["GET", "POST"])
def api_visit_endpoint():
    ok, err_msg, _ = _validate_request_key()
    if not ok:
        return jsonify({"status": "error", "code": 403, "msg": err_msg}), 403
    uid = request.args.get("visit") or request.args.get("uid") or (request.json.get("uid") if request.is_json else None)
    return _handle_visit_api(uid)


@app.route("/api/team5", methods=["GET", "POST"])
@app.route("/team5", methods=["GET", "POST"])
def api_team5_endpoint():
    ok, err_msg, _ = _validate_request_key()
    if not ok:
        return jsonify({"status": "error", "code": 403, "msg": err_msg}), 403
    uid = request.args.get("team5") or request.args.get("uid") or (request.json.get("uid") if request.is_json else None)
    return _handle_team5_api(uid)


@app.route("/api/spamkb", methods=["GET", "POST"])
@app.route("/spamkb", methods=["GET", "POST"])
def api_spamkb_endpoint():
    ok, err_msg, _ = _validate_request_key()
    if not ok:
        return jsonify({"status": "error", "code": 403, "msg": err_msg}), 403
    uid = request.args.get("spamkb") or request.args.get("uid") or (request.json.get("uid") if request.is_json else None)
    return _handle_spamkb_api(uid)


@app.route("/cmd/team5", methods=["GET", "POST"])
@app.route("/cmd/team5/<target_uid>", methods=["GET", "POST"])
def api_team5(target_uid=None):
    if not BOT_SESSION["loop"] or not BOT_SESSION["bot_uid"]:
        return jsonify({"ok": False, "msg": "Bot chưa online trong sảnh"}), 400
    
    clean_target = "15162700166"
    if target_uid:
        digits = "".join(filter(str.isdigit, str(target_uid)))
        if digits:
            clean_target = digits
    
    future = asyncio.run_coroutine_threadsafe(_async_create_team5(), BOT_SESSION["loop"])
    try:
        team_code = future.result(timeout=8.0)
    except Exception:
        team_code = None

    target_int = int(clean_target)
    async def _send_team5_invite():
        try:
            await asyncio.sleep(0.4)
            pkt = await bot_core.SendInvite(target_int, BOT_SESSION["key"], BOT_SESSION["iv"], BOT_SESSION.get("region", "VN"))
            await _send_online_packet(pkt)
            print(f"[+] Sent in-game squad invite 1 to {target_int} after creating team5")
            await asyncio.sleep(0.8)
            await _send_online_packet(pkt)
            print(f"[+] Sent in-game squad invite 2 to {target_int}")
        except Exception as e:
            print(f"[_send_team5_invite error]: {e}")
    asyncio.run_coroutine_threadsafe(_send_team5_invite(), BOT_SESSION["loop"])

    return jsonify({
        "ok": True,
        "team_code": str(team_code) if team_code else None,
        "invited_uid": clean_target,
        "bot_name": BOT_SESSION.get("name"),
        "bot_uid": BOT_SESSION.get("bot_uid"),
        "msg": f"Đã tạo sảnh Team 5 thành công và gửi lời mời in-game tới UID {clean_target}!"
    })


@app.route("/cmd/join/<team_code>", methods=["GET", "POST"])
def api_join(team_code):
    if not BOT_SESSION["loop"] or not BOT_SESSION["bot_uid"]:
        return jsonify({"ok": False, "msg": "Bot chưa online trong sảnh"}), 400
    digits = "".join(filter(str.isdigit, str(team_code)))
    if not digits:
        return jsonify({"ok": False, "msg": "Mã đội không hợp lệ"}), 400
    future = asyncio.run_coroutine_threadsafe(_async_join_squad(digits), BOT_SESSION["loop"])
    try:
        ok = future.result(timeout=4.0)
    except Exception:
        ok = True
    return jsonify({
        "ok": ok,
        "team_code": digits,
        "region": BOT_SESSION.get("region", "VN"),
        "bot_uid": BOT_SESSION.get("bot_uid"),
        "name": BOT_SESSION.get("name"),
        "msg": f"Đã gửi lệnh vào đội mã {digits}..."
    })


@app.route("/cmd/exit", methods=["GET", "POST"])
def api_exit():
    if not BOT_SESSION["loop"] or not BOT_SESSION["bot_uid"]:
        return jsonify({"ok": False, "msg": "Bot chưa online trong sảnh"}), 400
    async def _do_exit():
        try:
            pkt = await bot_core.ExiT(int(BOT_SESSION["bot_uid"]), BOT_SESSION["key"], BOT_SESSION["iv"])
            await _send_online_packet(pkt)
            print("[+] Bot sent ExiT squad packet")
        except Exception as e:
            print(f"[_do_exit error]: {e}")
    asyncio.run_coroutine_threadsafe(_do_exit(), BOT_SESSION["loop"])
    return jsonify({"ok": True, "msg": "Bot đã rời phòng/sảnh!"})


@app.route("/cmd/evo", methods=["GET", "POST"])
def api_evo():
    if not BOT_SESSION["loop"] or not BOT_SESSION["bot_uid"]:
        return jsonify({"ok": False, "msg": "Bot chưa online trong sảnh"}), 400
    asyncio.run_coroutine_threadsafe(
        bot_core.evo_gun_cycle([BOT_SESSION["bot_uid"]], bot_core.EVO_IDS, BOT_SESSION["key"], BOT_SESSION["iv"], BOT_SESSION["region"]),
        BOT_SESSION["loop"]
    )
    return jsonify({"ok": True, "msg": "Bot đã bắt đầu múa combo súng nâng cấp!"})


@app.route("/cmd/accept/<target_uid>", methods=["GET", "POST"])
def api_accept_friend(target_uid):
    clean_uid = "".join(filter(str.isdigit, str(target_uid)))
    if not clean_uid:
        return jsonify({"ok": False, "msg": "UID không hợp lệ"}), 400
    
    import requests
    from ff_core import get_all_cached_sessions, pb_field, encrypt_aes
    sessions = get_all_cached_sessions()
    if not sessions:
        return jsonify({"ok": False, "msg": "Chưa có session bot"}), 400

    results = []
    for s in sessions[:3]:
        tok = s.get("token")
        s_url = s.get("server_url", "https://clientbp.ppmainecoonghj.com").rstrip("/")
        hdrs = {
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 14; Pixel 8 Build/UP1A.231005.007)",
            "Connection": "Keep-Alive",
            "Content-Type": "application/octet-stream",
            "Authorization": f"Bearer {tok}",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": s.get("release_version", "OB55")
        }
        try:
            r = requests.post(f"{s_url}/ConfirmFriendRequest", data=encrypt_aes(pb_field(1, int(clean_uid))), headers=hdrs, timeout=5)
            if r.status_code == 200:
                results.append({"name": s.get("name"), "status": "200 OK (Đã chấp nhận kết bạn)"})
            elif b"BR_FRIEND_NO_REQUEST" in r.content:
                results.append({"name": s.get("name"), "status": "Chưa có lời mời kết bạn từ UID này"})
            else:
                results.append({"name": s.get("name"), "status": f"Mã lỗi: {r.status_code}"})
        except Exception as e:
            results.append({"name": s.get("name"), "status": str(e)})

    return jsonify({
        "ok": True,
        "target_uid": clean_uid,
        "results": results,
        "msg": f"Đã gửi lệnh chấp nhận kết bạn cho UID {clean_uid}!"
    })


@app.route("/cmd/invite/<target_uid>", methods=["GET", "POST"])
def api_invite(target_uid):
    if not BOT_SESSION["loop"] or not BOT_SESSION["bot_uid"]:
        return jsonify({"ok": False, "msg": "Bot chưa online trong sảnh"}), 400
    digits = "".join(filter(str.isdigit, str(target_uid)))
    if not digits:
        return jsonify({"ok": False, "msg": "UID không hợp lệ"}), 400
    async def _do_invite():
        try:
            pkt = await bot_core.SendInvite(int(digits), BOT_SESSION["key"], BOT_SESSION["iv"], BOT_SESSION.get("region", "VN"))
            sent = await _send_online_packet(pkt)
            print(f"[+] Sent in-game squad invite to {digits}: {sent} ({len(pkt)} bytes)")
            return bool(sent)
        except Exception as e:
            print(f"[_do_invite error]: {e}")
            return False
    future = asyncio.run_coroutine_threadsafe(_do_invite(), BOT_SESSION["loop"])
    try:
        ok = future.result(timeout=4.0)
    except Exception:
        ok = True
    return jsonify({
        "ok": ok,
        "target_uid": digits,
        "msg": f"Đã gửi lời mời trực tiếp in-game tới UID {digits}!"
    })


@app.route("/cmd/stop", methods=["GET", "POST"])
def api_stop():
    bot_core.evo_cycle_running = False
    bot_core.fast_spam_running = False
    bot_core.freeze_running = False
    return jsonify({"ok": True, "msg": "Đã dừng múa hành động!"})


# ───────────────────────────────────────────────────────────────
# AUTO-PING KEEP-ALIVE (Chống ngủ đông Render 5 phút / lần)
# ───────────────────────────────────────────────────────────────
APP_URL_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "app_url.txt")


def _get_app_url():
    url = os.environ.get("RENDER_EXTERNAL_URL") or os.environ.get("APP_URL")
    if url:
        return url.strip().rstrip("/")
    if os.path.exists(APP_URL_FILE):
        try:
            with open(APP_URL_FILE, "r", encoding="utf-8") as f:
                saved = f.read().strip()
                if saved.startswith("http"):
                    return saved.rstrip("/")
        except Exception:
            pass
    return None


def _keep_alive_worker():
    """Tự động gửi HTTP GET mỗi 5 phút tới web service để Render không bao giờ sleep"""
    import time as _t
    print("[*] Keep-Alive auto-ping daemon started (5 phút / lần)...")
    _t.sleep(20)
    while True:
        try:
            target = _get_app_url()
            if target:
                ping_endpoint = f"{target}/healthz"
                try:
                    r = requests.get(ping_endpoint, timeout=12)
                    print(f"[Keep-Alive 5m] Đã ping {ping_endpoint} -> HTTP {r.status_code} (Chống ngủ Render)")
                except Exception as ping_err:
                    print(f"[Keep-Alive 5m] Ping notice: {ping_err}")
            else:
                try:
                    requests.get(f"http://127.0.0.1:{PORT}/healthz", timeout=5)
                except Exception:
                    pass
        except Exception as e:
            print(f"[Keep-Alive error]: {e}")
        _t.sleep(300)


def run_web():
    try:
        print(f"[*] Flask listening on 0.0.0.0:{PORT}")
        app.run(
            host="0.0.0.0",
            port=PORT,
            use_reloader=False,
            threaded=True,
        )
    except Exception as e:
        print(f"[*] Flask notice: {e}")


# ───────────────────────────────────────────────────────────────
# Entry
# ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    threading.Thread(target=run_web, daemon=True).start()
    threading.Thread(target=_keep_alive_worker, daemon=True).start()
    try:
        asyncio.run(StarTinG())
    except KeyboardInterrupt:
        print("\n[!] Interrupted by user. Bot Stopped.")
