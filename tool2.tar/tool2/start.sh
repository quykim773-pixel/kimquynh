#!/bin/bash
# HAKURA2 SERVICE RUNNER (Web API + Telegram Bot)
echo "[+] Starting HAKURA2 Telegram Bot..."
python3 telegram_bot.py &

echo "[+] Starting HAKURA2 Web API (Flask)..."
python3 app.py
