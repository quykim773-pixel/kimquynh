# -*- coding: utf-8 -*-
"""
HAKURA2 MATCH ENGINE — AUTOMATED 1-MATCH FARMER (SERVER VN)
Connects to Garena TCP Gateway -> StartMatch -> Receives UDP Match Info (Port 10016/10017)
-> Handshakes UDP -> Loads Map (Thunder+Sharma) -> Ping Keepalive -> Waits until Server Finishes Match
"""

import sys
import os
import asyncio
import json
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TOOL_DIR = "/storage/emulated/0/Download/Tool"
sys.path.insert(0, BASE_DIR)
sys.path.insert(0, TOOL_DIR)

import login_engine
from auth_helper import build_ob55_online_auth
from master import (
    start_game_lone_wolf,
    build_match_startup_packets,
    play_game,
    decode_protobuf,
    resolve_host_cloudflare
)

ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.json")
TOKEN_CACHE_FILE = os.path.join(BASE_DIR, "token_cache.json")


async def run_one_match(target_uid=None):
    print("=" * 60)
    print("🎮 HAKURA2 FF MATCH AUTOMATION — CHẠY 1 TRẬN CHIẾN ĐẤU (VN)")
    print("=" * 60)

    # 1. Chọn tài khoản
    accs = []
    if os.path.exists(ACCOUNTS_FILE):
        try:
            with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
                accs = json.load(f)
        except Exception:
            pass

    if not accs:
        print("❌ Không có tài khoản trong accounts.json!")
        return False

    chosen = accs[-1] # Lấy tài khoản mới nhất
    if target_uid:
        for a in accs:
            if str(a.get("uid")) == str(target_uid):
                chosen = a
                break

    uid = str(chosen["uid"])
    pwd = str(chosen["password"])
    print(f"[*] Sử dụng tài khoản UID: {uid} (Server: VN)")

    # 2. Đăng nhập lấy Session
    print("[*] Đang đăng nhập máy chủ Garena VN...")
    login_data = await login_engine.do_login(uid, pwd, "VN")
    if not login_data or not login_data.get("token"):
        print("❌ Đăng nhập thất bại!")
        return False

    bot_uid = login_data["bot_uid"]
    key = login_data["key"]
    iv = login_data["iv"]
    timestamp = login_data["timestamp"]
    online_ip = login_data["online_ip"]
    online_port = int(login_data["online_port"])
    acc_name = login_data["account_name"]

    print(f"[+] Đăng nhập thành công! Nhân vật: {acc_name} (UID: {bot_uid})")

    # 3. Tạo gói xác thực OnlineAutH
    OnlineAutH, _ = build_ob55_online_auth(
        int(bot_uid), login_data["token"], int(timestamp), key, iv
    )

    # 4. Mở kết nối TCP tới Gateway
    print(f"[*] Đang kết nối TCP Gateway: {online_ip}:{online_port}...")
    resolved_ip = await resolve_host_cloudflare(online_ip)
    reader, writer = await asyncio.open_connection(resolved_ip, online_port)
    writer.write(bytes.fromhex(OnlineAutH))
    await writer.drain()
    print("✅ Đã kết nối Gateway thành công!")

    # 5. Gửi lệnh tìm trận Lone Wolf (Chiến Địa 1v1/2v2)
    print("[*] Đang gửi lệnh tìm trận (StartMatch) lên máy chủ Garena...")
    await start_game_lone_wolf("VN", "1.132.13", writer, key, iv)
    print("📡 Đang ghép trận... (Chờ 5 - 40 giây)...")

    # 6. Lắng nghe Gateway phản hồi thông tin máy chủ UDP
    udp_match_info = None
    start_wait = time.time()
    while time.time() - start_wait < 90:
        try:
            data = await asyncio.wait_for(reader.read(9999), timeout=3.0)
            if not data:
                break
            hex_data = data.hex()
            if hex_data.startswith("0300") and len(data) >= 300:
                print(f"[+] 🎉 MATCH FOUND! Đã tìm thấy trận đấu!")
                try:
                    res = json.loads(await decode_protobuf(hex_data[10:]))
                    token = None
                    udp_key = None
                    match_code = None
                    server_ip_port = None
                    block_val = None

                    if '42' in res and 'data' in res['42']:
                        match_code = res['42']['data']
                    if '5' in res and 'data' in res['5']:
                        res_f5 = res['5']['data']
                        server_ip_port = res_f5.get('2', {}).get('data')
                        udp_key = res_f5.get('3', {}).get('data')
                        token = res_f5.get('4', {}).get('data')
                        if '42' in res_f5:
                            match_code = res_f5['42']['data']
                        block_val = res_f5.get('1', {}).get('data')

                    if token and udp_key and match_code and server_ip_port:
                        udp_match_info = {
                            "token": token,
                            "udp_key": udp_key,
                            "match_code": match_code,
                            "server_ip_port": server_ip_port,
                            "block_val": block_val or 0
                        }
                        break
                except Exception as e:
                    print(f"[-] Decode error: {e}")
            elif hex_data.startswith("0300"):
                print("[*] Garena: Đang ghép trận...")
        except asyncio.TimeoutError:
            # Gửi lại start match nếu quá lâu
            try:
                await start_game_lone_wolf("VN", "1.132.13", writer, key, iv)
            except Exception:
                pass

    if not udp_match_info:
        print("[-] Hết thời gian chờ ghép trận. Vui lòng thử lại sau.")
        try:
            writer.close()
            await writer.wait_closed()
        except Exception:
            pass
        return False

    # 7. Chuẩn bị gói tin nạp map và vào trận UDP
    server_ip_port = udp_match_info["server_ip_port"]
    print(f"[+] Máy chủ trận đấu UDP: {server_ip_port}")
    print(f"[+] Match Code: {udp_match_info['match_code']}")

    thunder, sharma = await build_match_startup_packets(
        udp_match_info["token"],
        udp_match_info["udp_key"],
        udp_match_info["match_code"],
        bot_uid,
        udp_match_info["block_val"],
        server_ip=server_ip_port,
        region="VN",
        client_version="1.132.13"
    )

    # 8. Chạy UDP Match Loop
    print("🚀 Bắt đầu nạp nhân vật vào trận & chạy UDP Ping giữ phòng...")
    result = await play_game(
        server_ip_port,
        thunder,
        sharma,
        udp_match_info["udp_key"],
        udp_match_info["match_code"],
        bot_uid,
        "VN",
        "1.132.13",
        key,
        iv,
        match_index=1
    )

    print(f"🎉 KẾT QUẢ TRẬN ĐẤU: {result}")
    print(f"✅ Tài khoản {acc_name} ({bot_uid}) đã hoàn thành 1 trận đấu hợp lệ trên máy chủ Garena!")

    try:
        writer.close()
        await writer.wait_closed()
    except Exception:
        pass
    return True


if __name__ == "__main__":
    t_uid = sys.argv[1] if len(sys.argv) > 1 else None
    asyncio.run(run_one_match(t_uid))
