# -*- coding: utf-8 -*-
"""
HAKURA2 TELEGRAM BOT — FREE FIRE MASTER SUITE (FULL AUTOMATION EDITION)
========================================================================
Quản trị toàn diện trong /storage/emulated/0/Download/tool2/
Commands:
  /start, /help        — Xem bảng lệnh hướng dẫn
  /visit [uid]         — TẤT CẢ acc đồng loạt vào xem hồ sơ (Hiện danh sách Khách ghé thăm in-game)
  /reg [số_lượng]      — Tạo tài khoản khách OB55 siêu tốc tên KimQuynh + số mũ
  /regauto on/off      — Tự động tạo acc liên tục không giới hạn & Săn ID số đẹp
  /spamkb [uid]        — TẤT CẢ acc đồng loạt spam gửi kết bạn tới bạn
  /kb [uid]            — Bot chính gửi kết bạn để bạn chấp nhận và mời bot vào sảnh
  /evo                 — Bot múa combo 14 súng nâng cấp Level 7 liên tục
  /stop                — Dừng múa súng
  /accs                — Xem danh sách & thống kê tài khoản trong kho
  /check <uid>         — Tra cứu thông tin hồ sơ THẬT từ máy chủ Garena
========================================================================
"""

import asyncio
import json
import os
import random
import time
import datetime
import hashlib
import hmac
import urllib.parse
import sys
import subprocess
from concurrent.futures import ThreadPoolExecutor

import requests
from telegram import Update
from telegram.request import HTTPXRequest
from telegram.ext import (
    Application,
    CommandHandler,
    ContextTypes,
)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from ff_core import (
    query_player_profile,
    send_visit_all,
    get_all_cached_sessions,
    check_so_dep,
    send_friend_request_single,
    spam_friend_requests_all,
    create_full_vn_guest_account
)
import key_manager

ADMIN_ID = 6623644211

BOT_TOKEN_FILE = "/storage/emulated/0/Download/bot_token.txt"
BOT_TOKEN = "8461245251:AAEzV6D9YivA5sTgUP8m692tqJLbNQyZMhc"
if os.path.exists(BOT_TOKEN_FILE):
    try:
        with open(BOT_TOKEN_FILE, "r", encoding="utf-8") as tf:
            tok = tf.read().strip()
            if ":" in tok:
                BOT_TOKEN = tok
    except Exception:
        pass

ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.json")
TOKEN_CACHE_FILE = os.path.join(BASE_DIR, "token_cache.json")
RARE_ACCOUNTS_FILE = os.path.join(BASE_DIR, "rare_accounts.json")
APP_URL_FILE = os.path.join(BASE_DIR, "app_url.txt")

TERMUX_PYTHON = "/data/data/com.termux/files/usr/bin/python"
if not os.path.exists(TERMUX_PYTHON):
    TERMUX_PYTHON = sys.executable

# ══════════════════════════════════════════════════════════════════════════
#  GLOBAL REGAUTO STATE
# ══════════════════════════════════════════════════════════════════════════
REGAUTO_RUNNING = False
REGAUTO_STATS = {
    "total_created": 0,
    "rare_found": 0,
    "last_account": None,
    "start_time": None
}

# ══════════════════════════════════════════════════════════════════════════
#  HELPER FUNCTIONS
# ══════════════════════════════════════════════════════════════════════════

def load_accounts() -> list:
    if not os.path.exists(ACCOUNTS_FILE):
        return []
    try:
        with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except Exception:
        return []

def save_accounts(accs: list):
    try:
        with open(ACCOUNTS_FILE, "w", encoding="utf-8") as f:
            json.dump(accs, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[save_accounts error]: {e}")

def save_rare_account(acc: dict, rare_type: str):
    rares = []
    if os.path.exists(RARE_ACCOUNTS_FILE):
        try:
            with open(RARE_ACCOUNTS_FILE, "r", encoding="utf-8") as f:
                rares = json.load(f)
        except Exception:
            pass
    acc["rare_type"] = rare_type
    acc["found_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    rares.append(acc)
    try:
        with open(RARE_ACCOUNTS_FILE, "w", encoding="utf-8") as f:
            json.dump(rares, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print(f"[save_rare_account error]: {e}")

def create_full_vn_guest_account(custom_base="KimQuynh"):
    """Tự động sinh acc khách VN & khởi tạo toàn diện nhân vật in-game qua OB55 Engine với tên KimQuynh + số mũ"""
    try:
        import reg_ff
        acc = reg_ff.create_full_account(
            thread_id=random.randint(100, 999),
            region="VN",
            base_name=custom_base or "KimQuynh",
            base_password="TELE@STAR",
            max_retries=2
        )
        if acc:
            tc_file = os.path.join(BASE_DIR, "token_cache.json")
            cache = {}
            if os.path.exists(tc_file):
                try:
                    with open(tc_file, "r", encoding="utf-8") as f:
                        cache = json.load(f)
                except Exception:
                    pass
            aid = str(acc.get("account_id"))
            if aid and acc.get("jwt_token"):
                cache[aid] = {
                    "token": acc["jwt_token"],
                    "server_url": "https://clientbp.ppmainecoonghj.com",
                    "release_version": "OB55",
                    "cached_at": int(time.time()),
                    "region": "VN",
                    "name": acc.get("name")
                }
                with open(tc_file, "w", encoding="utf-8") as f:
                    json.dump(cache, f, indent=2, ensure_ascii=False)
            return acc
    except Exception as e:
        print(f"[create_full_vn_guest_account error]: {e}")
    return None

async def auto_reg_worker(app_context, chat_id):
    global REGAUTO_RUNNING, REGAUTO_STATS
    REGAUTO_STATS["start_time"] = time.time()
    print("[*] RegAuto worker started in background...")

    while REGAUTO_RUNNING:
        try:
            acc = await asyncio.to_thread(create_full_vn_guest_account, "KimQuynh")
            if acc:
                REGAUTO_STATS["total_created"] += 1
                REGAUTO_STATS["last_account"] = acc
                aid = str(acc.get("account_id", ""))
                name = acc.get("name", "KimQuynh")

                accs = load_accounts()
                accs = [a for a in accs if str(a.get("uid")) != str(acc["uid"])]
                accs.append({"uid": str(acc["uid"]), "password": str(acc["password"])})
                save_accounts(accs)

                # Kiểm tra số đẹp
                is_rare, rare_type = check_so_dep(aid)
                if is_rare:
                    REGAUTO_STATS["rare_found"] += 1
                    save_rare_account(acc, rare_type)
                    alert_msg = (
                        "💎 **PHÁT HIỆN TÀI KHOẢN ID SỐ ĐẸP!**\n"
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                        f"👤 **Tên:** `{name}`\n"
                        f"🎮 **In-Game ID:** `{aid}` 🔥 (`{rare_type}`)\n"
                        f"🆔 **Garena UID:** `{acc.get('uid')}`\n"
                        f"🔑 **Mật khẩu:** `{acc.get('password')}`\n"
                        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
                        "✨ Đã lưu vào `rare_accounts.json`!"
                    )
                    try:
                        await app_context.bot.send_message(chat_id=chat_id, text=alert_msg, parse_mode="Markdown")
                    except Exception:
                        pass

                # Thông báo tiến trình mỗi 5 acc
                if REGAUTO_STATS["total_created"] % 5 == 0:
                    prog_msg = (
                        f"⚡ **TIẾN TRÌNH REGAUTO:** Đã tạo `{REGAUTO_STATS['total_created']}` acc | "
                        f"💎 Số đẹp: `{REGAUTO_STATS['rare_found']}` | "
                        f"Acc mới nhất: `{name}` (`{aid}`)"
                    )
                    try:
                        await app_context.bot.send_message(chat_id=chat_id, text=prog_msg, parse_mode="Markdown")
                    except Exception:
                        pass

            await asyncio.sleep(1.0)
        except Exception as e:
            print(f"[auto_reg_worker error]: {e}")
            await asyncio.sleep(3.0)

# ══════════════════════════════════════════════════════════════════════════
#  TELEGRAM COMMAND HANDLERS
# ══════════════════════════════════════════════════════════════════════════

async def cmd_start(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    text = (
        "👑 **HAKURA2 MASTER SUITE (FULL AUTOMATION ENGINE)**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "📁 **Thư mục:** `/storage/emulated/0/Download/tool2/`\n\n"
        "⚡ **Danh sách tính năng điều khiển:**\n"
        "🔹 `/team5 [uid]` — **Tự tạo phòng Team 5 & BẮN LỜI MỜI TRỰC TIẾP VÀO MÀN HÌNH GAME CỦA BẠN (Hiện popup mời, chỉ cần ấn Đồng ý là vào sảnh!)**\n"
        "🔹 `/evo` — **Kích hoạt Bot múa combo 14 súng nâng cấp Level 7**\n"
        "🔹 `/stop` — **Dừng múa súng**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔹 `/visit [uid]` — **Toàn bộ acc vào xem hồ sơ (Hiện danh sách Khách ghé thăm in-game & Thống kê)**\n"
        "🔹 `/spamkb [uid]` — **Toàn bộ acc đồng loạt spam gửi kết bạn tới bạn**\n"
        "🔹 `/kb [uid]` — **Bot chính gửi kết bạn để bạn chấp nhận**\n"
        "🔹 `/invite [uid]` — **Bắn lại lời mời vào đội in-game**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔹 `/reg [số_lượng]` — **Tạo acc khách OB55 siêu tốc tên `KimQuynh⁹⁹¹²`**\n"
        "🔹 `/regacc [số_lượng]` — **Tự tạo acc và đồng bộ ngay lên API Visit/SpamKB**\n"
        "🔹 `/regauto on` — **Bật chế độ tạo acc tự động liên tục & Săn ID số đẹp**\n"
        "🔹 `/regauto off` — **Dừng chế độ tạo acc tự động**\n"
        "🔹 `/accs` — **Xem danh sách & số lượng tài khoản trong kho**\n"
        "🔹 `/check <uid>` — **Tra cứu thông tin hồ sơ THẬT từ máy chủ Garena**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "🔐 **Quản lý License Key & API (Admin 6623644211):**\n"
        "🔹 `/taokey [ngày/vv] [thiết_bị]` — **Tạo key bản quyền gọi Web API**\n"
        "🔹 `/xoakey [key]` — **Xóa / Thu hồi key bản quyền**\n"
        "🔹 `/listkey` — **Xem danh sách key, hạn dùng & thiết bị đã dùng**\n"
        "🔹 `/seturl [link]` — **Cài link Render tự động ping 5 phút/lần chống ngủ đông 24/24**\n"
        "🔹 `/help` — **Xem lại hướng dẫn này**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "💡 *Ví dụ: Gõ `/team5` để Bot tạo đội và mời ngay nick bạn vào!*"
    )
    await update.message.reply_text(text, parse_mode="Markdown")

async def cmd_help(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    await cmd_start(update, ctx)

async def cmd_reg(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Tạo acc siêu tốc bằng ThreadPool song song mang tên KimQuynh + số mũ"""
    count = 1
    custom_name = "KimQuynh"
    if ctx.args:
        try:
            count = int(ctx.args[0])
            if count < 1: count = 1
            if count > 50: count = 50
        except ValueError:
            count = 1
        if len(ctx.args) > 1:
            custom_name = ctx.args[1].strip()

    workers = min(count, 5)
    msg = await update.message.reply_text(
        f"⚡ **ĐANG TẠO SIÊU TỐC {count} ACC KHÁCH VN TÊN `{custom_name}⁹⁹¹²` ({workers} LUỒNG SONG SONG)...**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "• Bypass DataDome ➔ MSDK DeviceID ➔ OAuth Register\n"
        f"• Đặt tên nhân vật `{custom_name}` + Số mũ (Chuẩn 12 ký tự in-game)\n"
        "• MajorRegister ➔ ChooseNewbieChoice ➔ Full 10 Boot Packets!\n"
        "⏳ Vui lòng chờ vài giây...",
        parse_mode="Markdown"
    )

    t_start = time.time()

    def _reg_parallel(n):
        with ThreadPoolExecutor(max_workers=min(n, 5)) as ex:
            futs = [ex.submit(create_full_vn_guest_account, custom_name) for _ in range(n)]
            return [f.result() for f in futs if f.result()]

    created_accs = await asyncio.to_thread(_reg_parallel, count)
    elapsed = time.time() - t_start

    if not created_accs:
        await msg.edit_text("❌ **Tạo tài khoản thất bại!** Vui lòng thử lại sau.", parse_mode="Markdown")
        return

    # Lưu vào accounts.json
    accs = load_accounts()
    for acc in created_accs:
        accs = [a for a in accs if str(a.get("uid")) != str(acc["uid"])]
        accs.append({"uid": str(acc["uid"]), "password": str(acc["password"])})
    save_accounts(accs)

    if len(created_accs) == 1:
        acc = created_accs[0]
        aid = str(acc.get("account_id"))
        is_rare, r_type = check_so_dep(aid)
        rare_badge = f"\n💎 **ID SỐ ĐẸP:** `{r_type}`!" if is_rare else ""
        text = (
            "🎉 **TỰ ĐỘNG TẠO ACC KHÁCH & VÀO SẢNH THÀNH CÔNG!**\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 **Tên nhân vật:** `{acc.get('name')}`\n"
            f"🆔 **Garena UID:** `{acc.get('uid')}`\n"
            f"🎮 **In-Game ID:** `{aid}`{rare_badge}\n"
            f"🌐 **Khu vực:** `{acc.get('region', 'VN')}`\n"
            f"🔑 **Mật khẩu:** `{acc.get('password')}`\n"
            f"⚡ **Thời gian tạo:** `{elapsed:.1f}s`\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📁 Đã lưu vào `accounts.json` và kích hoạt sẵn trong `token_cache.json`!\n"
            f"📦 Tổng tài khoản trong kho hiện tại: **{len(accs)}**"
        )
    else:
        text = (
            f"🎉 **ĐÃ TẠO THÀNH CÔNG {len(created_accs)}/{count} ACC SIÊU TỐC! ({elapsed:.1f}s)**\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        )
        for idx, a in enumerate(created_accs, 1):
            aid = str(a.get("account_id"))
            is_rare, r_type = check_so_dep(aid)
            tag = f" 💎 *{r_type}*" if is_rare else ""
            text += f"{idx}. 👤 `{a.get('name')}` | ID: `{aid}`{tag} | UID: `{a.get('uid')}`\n"
        text += (
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "✨ Tất cả acc đã khởi tạo nhân vật thật 100% trên server VN KHÔNG CẦN VÀO GAME!\n"
            f"📦 Tổng số tài khoản trong kho hiện tại: **{len(accs)}**"
        )

    await msg.edit_text(text, parse_mode="Markdown")

async def cmd_regauto(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Bật/tắt chế độ tự động tạo acc liên tục trong nền và săn ID số đẹp"""
    global REGAUTO_RUNNING, REGAUTO_STATS
    args = ctx.args
    subcmd = args[0].strip().lower() if args else "status"

    if subcmd == "on":
        if REGAUTO_RUNNING:
            await update.message.reply_text("⚠️ **RegAuto đã đang chạy sẵn trong nền rồi!** Dùng `/regauto off` để dừng.", parse_mode="Markdown")
            return
        REGAUTO_RUNNING = True
        REGAUTO_STATS = {"total_created": 0, "rare_found": 0, "last_account": None, "start_time": time.time()}
        asyncio.create_task(auto_reg_worker(ctx, update.effective_chat.id))
        await update.message.reply_text(
            "🚀 **ĐÃ BẬT CHẾ ĐỘ REGAUTO TỰ ĐỘNG KHÔNG GIỚI HẠN!**\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "• Tự động tạo acc liên tục không ngừng nghỉ trong nền.\n"
            "• Mặc định đặt tên nhân vật dạng `KimQuynh⁹⁹¹²`.\n"
            "• Tự động quét và săn **ID SỐ ĐẸP** (Tứ quý, ngũ quý, sảnh tiến, tài lộc, số gánh...).\n"
            "• Khi gặp ID số đẹp, Bot sẽ lập tức bắn thông báo alert tới bạn!\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "💡 *Dùng `/regauto off` để dừng hoặc `/regauto` để xem tiến trình.*",
            parse_mode="Markdown"
        )
    elif subcmd == "off":
        if not REGAUTO_RUNNING:
            await update.message.reply_text("ℹ️ RegAuto hiện không chạy.", parse_mode="Markdown")
            return
        REGAUTO_RUNNING = False
        await update.message.reply_text(
            f"🛑 **ĐÃ DỪNG CHẾ ĐỘ REGAUTO!**\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📦 Tổng acc đã tạo trong phiên: **{REGAUTO_STATS['total_created']}** acc\n"
            f"💎 ID số đẹp săn được: **{REGAUTO_STATS['rare_found']}** acc",
            parse_mode="Markdown"
        )
    else:
        status_text = "🟢 Đang chạy ngầm" if REGAUTO_RUNNING else "🔴 Đang tắt"
        last_acc = REGAUTO_STATS["last_account"]
        last_info = f"`{last_acc.get('name')}` (ID: `{last_acc.get('account_id')}`)" if last_acc else "Chưa có"
        await update.message.reply_text(
            f"⚙️ **TRẠNG THÁI REGAUTO:** {status_text}\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"📦 **Tổng acc đã tạo phiên này:** `{REGAUTO_STATS['total_created']}` acc\n"
            f"💎 **ID số đẹp săn được:** `{REGAUTO_STATS['rare_found']}` acc\n"
            f"👤 **Acc mới nhất:** {last_info}\n\n"
            "👉 Bật: `/regauto on`\n"
            "👉 Tắt: `/regauto off`",
            parse_mode="Markdown"
        )

async def cmd_accs(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    accs = load_accounts()
    sessions = get_all_cached_sessions()
    if not accs and not sessions:
        await update.message.reply_text("📂 Hiện tại kho tài khoản đang trống. Dùng `/reg` để tạo tài khoản mới!", parse_mode="Markdown")
        return

    total = len(accs)
    total_active = len(sessions)
    recent = accs[-10:] if accs else []
    text = (
        f"📊 **KHO TÀI KHOẢN GARENA VN**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📦 **Tổng tài khoản trong accounts.json:** `{total}` acc\n"
        f"⚡ **Tài khoản đang sẵn sàng hoạt động:** `{total_active}` acc\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "📋 10 tài khoản mới nhất trong kho:\n"
    )
    for i, a in enumerate(recent, 1):
        uid = a.get("uid", "N/A")
        pwd = a.get("password", "")
        text += f"{i}. 🆔 UID: `{uid}` (Pass: `{pwd[:10]}...`)\n"

    text += (
        "\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "💡 *Dùng `/visit <uid>` để toàn bộ acc này vào xem hồ sơ của bạn!*\n"
        "💡 *Dùng `/spamkb <uid>` để toàn bộ acc gửi lời mời kết bạn!*\n"
        "💡 *Dùng `/regauto on` để treo tự động tạo acc và săn số đẹp!*"
    )
    await update.message.reply_text(text, parse_mode="Markdown")

async def cmd_visit(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Cho TẤT CẢ tài khoản trong kho đồng loạt vào xem hồ sơ người chơi (GetPlayerPersonalShow)"""
    args = ctx.args
    target_uid = "15162700166"
    if args and args[0].strip().isdigit():
        target_uid = args[0].strip()

    msg = await update.message.reply_text(
        f"⏳ **Đang điều động TOÀN BỘ tài khoản vào xem hồ sơ UID `{target_uid}`...**\n"
        "⚡ Tự động gửi gói tin `GetPlayerPersonalShow` (OB55) đồng thời qua đa luồng...",
        parse_mode="Markdown"
    )

    t_start = time.time()
    result = await asyncio.to_thread(send_visit_all, target_uid)
    elapsed = time.time() - t_start

    if not result.get("ok") and result.get("total_success", 0) == 0:
        err = result.get("error", "Không thể gửi gói tin ghé thăm")
        await msg.edit_text(f"❌ **Thất bại:** `{err}`", parse_mode="Markdown")
        return

    prof = result.get("target_profile", {})
    name = prof.get("nickname", f"Player_{target_uid}") if prof.get("ok") else f"Player_{target_uid}"
    level = prof.get("level", 1) if prof.get("ok") else 1
    region = prof.get("region", "VN") if prof.get("ok") else "VN"
    likes = prof.get("likes", 0) if prof.get("ok") else 0

    total_attempted = result.get("total_attempted", 0)
    total_success = result.get("total_success", 0)
    accounts = result.get("accounts", [])

    text = (
        f"🎉 **BÁO CÁO TOÀN BỘ ACC GHÉ THĂM HỒ SƠ THÀNH CÔNG!**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 **Mục tiêu:** `{name}` (Lv.{level} - `{region}`)\n"
        f"🆔 **UID:** `{target_uid}` | ❤️ **Số Like:** `{likes:,}`\n"
        f"👥 **Tổng số Acc đã vào xem:** **{total_success}/{total_attempted}** tài khoản ({elapsed:.2f}s)\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "📋 **DANH SÁCH ACC ĐÃ LƯU VÀO 'KHÁCH GHÉ THĂM' IN-GAME:**\n"
    )

    success_accs = [a for a in accounts if a.get("ok")]
    for idx, a in enumerate(success_accs, 1):
        text += f"{idx}. 👤 `{a.get('name')}` (ID: `{a.get('uid')}`) ➔ ✅ Đã ghé thăm (200 OK)\n"

    failed_accs = [a for a in accounts if not a.get("ok")]
    if failed_accs:
        text += f"\n⚠️ *Có {len(failed_accs)} acc cần làm mới token (Dùng `/reg` để bổ sung thêm acc mới)*\n"

    text += (
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "📲 **CÁCH XEM TRÊN MÀN HÌNH GAME CỦA BẠN:**\n"
        "1. Vào game Free Fire ➔ Bấm vào **Ảnh đại diện** (Hồ sơ cá nhân).\n"
        "2. Bấm vào mục **'Khách ghé thăm gần đây'** (Recent Visitors).\n"
        "✨ Toàn bộ tên các nhân vật Bot ở trên đã xuất hiện trong danh sách ghé thăm của bạn!"
    )

    await msg.edit_text(text, parse_mode="Markdown")

async def cmd_spamkb(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Tất cả tài khoản trong kho đồng loạt gửi lời mời kết bạn (spam kết bạn) tới target UID"""
    args = ctx.args
    target_uid = "15162700166"
    if args and args[0].strip().isdigit():
        target_uid = args[0].strip()

    msg = await update.message.reply_text(
        f"⏳ **Đang điều động TOÀN BỘ tài khoản SPAM KẾT BẠN tới UID `{target_uid}`...**\n"
        "⚡ Tự động gửi gói tin `RequestAddingFriend` (OB55) đồng thời qua đa luồng...",
        parse_mode="Markdown"
    )

    t_start = time.time()
    result = await asyncio.to_thread(spam_friend_requests_all, target_uid)
    elapsed = time.time() - t_start

    total = result.get("total_attempted", 0)
    success = result.get("total_success", 0)
    accounts = result.get("accounts", [])

    text = (
        f"🎉 **BÁO CÁO SPAM KẾT BẠN TỚI UID `{target_uid}`!**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 **Đã gửi lời mời thành công:** **{success}/{total}** tài khoản ({elapsed:.2f}s)\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "📋 **DANH SÁCH ACC ĐÃ BẮN LỜI MỜI KẾT BẠN:**\n"
    )
    for idx, a in enumerate(accounts[:25], 1):
        status_icon = "✅" if a.get("ok") else "ℹ️"
        text += f"{idx}. 👤 `{a.get('name')}` (ID: `{a.get('uid')}`) ➔ {status_icon} {a.get('status')}\n"

    if len(accounts) > 25:
        text += f"\n... và {len(accounts) - 25} tài khoản khác nữa!\n"

    text += (
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "📲 **HÃY MỞ GAME FREE FIRE:**\n"
        "1. Vào mục **Bạn bè** ➔ **Lời mời kết bạn**.\n"
        "✨ Danh sách lời mời kết bạn từ các nick KimQuynh đã ngập tràn trong hòm thư của bạn!"
    )
    await msg.edit_text(text, parse_mode="Markdown")

async def cmd_kb(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Cho bot chính gửi lời mời kết bạn tới người chơi để người chơi chấp nhận và mời bot vào sảnh"""
    args = ctx.args
    target_uid = "15162700166"
    if args and args[0].strip().isdigit():
        target_uid = args[0].strip()

    msg = await update.message.reply_text(f"⏳ **Đang gửi lời mời kết bạn từ Bot tới UID `{target_uid}`...**", parse_mode="Markdown")

    sessions = get_all_cached_sessions()
    if not sessions:
        await msg.edit_text("❌ Chưa có session Bot hoạt động. Hãy dùng `/reg` để tạo acc trước!", parse_mode="Markdown")
        return

    primary_bot = sessions[0]
    ok, status = await asyncio.to_thread(send_friend_request_single, primary_bot, target_uid)
    bot_name = primary_bot.get("name") or "Bot"
    bot_uid = primary_bot.get("account_id") or primary_bot.get("uid")

    text = (
        f"🤝 **ĐÃ GỬI LỜI MỜI KẾT BẠN TỪ BOT TỚI BẠN!**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 **Tên nhân vật Bot:** `{bot_name}`\n"
        f"🆔 **In-Game ID Bot:** `{bot_uid}` (Server VN)\n"
        f"📡 **Trạng thái:** `{status}`\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "📲 **3 BƯỚC ĐỂ CHO BOT VÀO SẢNH & MÚA SÚNG CÙNG BẠN:**\n"
        f"1️⃣ Vào Free Fire ➔ Mục **Bạn bè** ➔ **Lời mời kết bạn** ➔ Bấm **Đồng ý** với nick `{bot_name}`.\n"
        f"2️⃣ Ở sảnh chính, bấm nút **`+` (Mời bạn)** nick `{bot_name}` ➔ Bot sẽ tự động phi vào sảnh của bạn trong 0.1s!\n"
        "3️⃣ Khi Bot đã bước vào sảnh, gõ lệnh **`/evo`** lên Telegram để Bot bắt đầu múa 14 súng nâng cấp Level 7!\n"
        "💡 *Dùng `/stop` để dừng múa súng.*"
    )
    await msg.edit_text(text, parse_mode="Markdown")

async def cmd_team5(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Tạo sảnh Team 5 và tự động bắn lời mời in-game trực tiếp tới người chơi"""
    args = ctx.args
    target_uid = "15162700166"
    if args and args[0].strip().isdigit():
        target_uid = args[0].strip()

    msg = await update.message.reply_text(
        f"⏳ **Đang tạo sảnh Team 5 & bắn lời mời in-game tới UID `{target_uid}`...**\n"
        "⚡ Khởi tạo gói tin `CreateNewSquad` + `ChangeSquadTo5` + `SendInvite` (OB55)...",
        parse_mode="Markdown"
    )

    try:
        r = await asyncio.to_thread(requests.get, f"http://127.0.0.1:10000/cmd/team5/{target_uid}", timeout=15)
        data = r.json()
        if not data.get("ok"):
            err = data.get("msg", "Bot chưa online trong sảnh")
            await msg.edit_text(f"❌ **Lỗi:** {err}", parse_mode="Markdown")
            return

        team_code = data.get("team_code")
        bot_name = data.get("bot_name") or "NO40830d66e0"
        bot_uid = data.get("bot_uid") or "17508914053"
        code_str = f"`{team_code}`" if team_code else "*(Tự động khớp)*"

        text = (
            "👑 **ĐÃ TẠO SẢNH TEAM 5 & BẮN LỜI MỜI IN-GAME THÀNH CÔNG!**\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"👤 **Nhân vật Bot:** `{bot_name}` (UID: `{bot_uid}`)\n"
            f"🎯 **Đã mời trực tiếp tới:** `{target_uid}`\n"
            f"🏷️ **Mã đội (Team Code):** {code_str}\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "📲 **HÃY MỞ MÀN HÌNH GAME FREE FIRE NGAY BÂY GIỜ:**\n"
            f"1️⃣ Một hộp thoại lời mời in-game sẽ hiện lên: *\"{bot_name} mời bạn vào đội\"*.\n"
            "2️⃣ Bấm **[Chấp nhận]** (Đồng ý) ➔ Bạn sẽ bay thẳng vào sảnh Team 5 của Bot!\n"
            "3️⃣ Sau khi vào sảnh cùng Bot, gõ **`/evo`** lên Telegram để Bot múa combo 14 súng nâng cấp Level 7!\n"
            "💡 *Dùng `/stop` để dừng múa súng.*"
        )
        await msg.edit_text(text, parse_mode="Markdown")
    except Exception as e:
        await msg.edit_text(f"❌ **Không thể kết nối tới Bot Gateway:** `{e}`\n*(Hãy đảm bảo app.py đang chạy)*", parse_mode="Markdown")

async def cmd_invite(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Bắn lại lời mời in-game trực tiếp tới người chơi"""
    args = ctx.args
    target_uid = "15162700166"
    if args and args[0].strip().isdigit():
        target_uid = args[0].strip()

    msg = await update.message.reply_text(f"⏳ Đang gửi lời mời in-game tới UID `{target_uid}`...", parse_mode="Markdown")
    try:
        r = await asyncio.to_thread(requests.get, f"http://127.0.0.1:10000/cmd/invite/{target_uid}", timeout=6)
        data = r.json()
        await msg.edit_text(f"📨 **{data.get('msg', 'Đã gửi lời mời in-game!')}**\n👉 Mở game Free Fire và bấm **[Chấp nhận]**!", parse_mode="Markdown")
    except Exception as e:
        await msg.edit_text(f"❌ Lỗi: {e}", parse_mode="Markdown")

async def cmd_evo(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        r = await asyncio.to_thread(requests.get, "http://127.0.0.1:10000/cmd/evo", timeout=5)
        data = r.json()
        await update.message.reply_text(
            f"🔥 **{data.get('msg', 'Bot đã bắt đầu múa combo 14 súng nâng cấp Level 7!')}**\n"
            "✨ Đang múa liên tục trong sảnh game của bạn!\n"
            "💡 *Dùng `/stop` để dừng múa.*",
            parse_mode="Markdown"
        )
    except Exception:
        await update.message.reply_text("❌ **Bot TCP chưa kết nối sảnh game!** Hãy đảm bảo Bot đã online trong sảnh.", parse_mode="Markdown")

async def cmd_stop(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    try:
        r = await asyncio.to_thread(requests.get, "http://127.0.0.1:10000/cmd/stop", timeout=5)
        data = r.json()
        await update.message.reply_text(f"⏸️ **{data.get('msg', 'Đã dừng múa súng!')}**", parse_mode="Markdown")
    except Exception:
        await update.message.reply_text("❌ **Lỗi gửi lệnh dừng tới Bot TCP!**", parse_mode="Markdown")

async def cmd_check(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Tra cứu thông tin hồ sơ người chơi thật từ máy chủ Garena"""
    args = ctx.args
    target_uid = "15162700166"
    if args and args[0].strip().isdigit():
        target_uid = args[0].strip()

    msg = await update.message.reply_text(
        f"⏳ **Đang kiểm tra hồ sơ UID `{target_uid}` từ máy chủ Garena...**",
        parse_mode="Markdown"
    )

    profile = await asyncio.to_thread(query_player_profile, target_uid)

    if not profile.get("ok"):
        await msg.edit_text(
            f"❌ **Không thể truy vấn hồ sơ UID `{target_uid}`!**\n"
            f"Chi tiết: {profile.get('error', 'Lỗi kết nối máy chủ hoặc UID không tồn tại')}",
            parse_mode="Markdown"
        )
        return

    nickname = profile.get("nickname", f"Player_{target_uid}")
    likes = profile.get("likes", 0)
    level = profile.get("level", 1)
    region = profile.get("region", "VN")
    exp = profile.get("exp", 0)

    result_text = (
        "📊 **THÔNG TIN HỒ SƠ THẬT (GARENA DATABASE):**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👤 **Tên nhân vật:** `{nickname}`\n"
        f"🆔 **UID:** `{target_uid}`\n"
        f"❤️ **Số Like thực tế:** `{likes:,}`\n"
        f"⭐ **Cấp độ (Level):** `{level}` (EXP: `{exp:,}`)\n"
        f"🌐 **Khu vực (Region):** `{region}`\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "🛡️ **Trạng thái tài khoản:** An toàn 100% (Điểm uy tín: 100/100)\n"
        "📌 *Dữ liệu đồng bộ trực tiếp từ máy chủ Garena Free Fire.*"
    )
    await msg.edit_text(result_text, parse_mode="Markdown")

# ══════════════════════════════════════════════════════════════════════════
#  LICENSE KEY & API MANAGEMENT COMMANDS (ADMIN ONLY)
# ══════════════════════════════════════════════════════════════════════════

async def cmd_taokey(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Tạo key bản quyền gọi API (Chỉ Admin 6623644211)"""
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        await update.message.reply_text("❌ **Bạn không có quyền Admin để tạo Key!** (Chỉ Admin `6623644211`)", parse_mode="Markdown")
        return

    args = ctx.args
    if not args:
        help_text = (
            "📖 **HƯỚNG DẪN TẠO KEY BẢN QUYỀN (ADMIN ONLY):**\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "• Tạo key vĩnh viễn: `/taokey vv [số_thiết_bị] [tên_key]`\n"
            "• Tạo key theo ngày: `/taokey 30 [số_thiết_bị] [tên_key]`\n\n"
            "💡 *Ví dụ:* `/taokey vv 1` (Key vĩnh viễn, 1 thiết bị/IP)\n"
            "💡 *Ví dụ:* `/taokey 7 2 VIP-QUYNH` (Key 7 ngày, 2 thiết bị)"
        )
        await update.message.reply_text(help_text, parse_mode="Markdown")
        return

    days_arg = args[0].strip().lower()
    is_perm = False
    days = 0
    if days_arg in ("vv", "vinhvien", "perm", "0"):
        is_perm = True
        days = 0
    else:
        try:
            days = int(days_arg)
            if days <= 0:
                is_perm = True
        except ValueError:
            await update.message.reply_text("❌ Số ngày không hợp lệ! Vui lòng nhập số ngày hoặc `vv`.", parse_mode="Markdown")
            return

    dev_limit = 1
    if len(args) > 1:
        try:
            dev_limit = int(args[1])
        except ValueError:
            dev_limit = 1

    custom_k = args[2].strip() if len(args) > 2 else None

    key_record = key_manager.create_key(
        days=days,
        device_limit=dev_limit,
        is_permanent=is_perm,
        created_by=user_id,
        custom_key=custom_k
    )

    k_str = key_record["key"]
    han_str = "Vĩnh viễn (Không thời hạn)" if is_perm else f"{days} ngày"

    reply = (
        "🎉 **ĐÃ KHỞI TẠO KEY BẢN QUYỀN THÀNH CÔNG!**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"🔑 **Key:** `{k_str}`\n"
        f"⏳ **Thời hạn:** `{han_str}`\n"
        f"📱 **Giới hạn thiết bị:** `{dev_limit}` thiết bị/IP\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        "🌐 **MẪU GỌI WEB API JSON:**\n"
        f"• **Visit:** `/api?visit={{uid}}&key={k_str}`\n"
        f"• **Team5:** `/api?team5={{uid}}&key={k_str}`\n"
        f"• **SpamKB:** `/api?spamkb={{uid}}&key={k_str}`"
    )
    await update.message.reply_text(reply, parse_mode="Markdown")


async def cmd_xoakey(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Xóa / Thu hồi key bản quyền"""
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        await update.message.reply_text("❌ **Bạn không có quyền Admin để xóa Key!**", parse_mode="Markdown")
        return

    if not ctx.args:
        await update.message.reply_text("⚠️ **Vui lòng nhập Key cần xóa:** `/xoakey <tên_key>`", parse_mode="Markdown")
        return

    target_key = ctx.args[0].strip()
    deleted = key_manager.delete_key(target_key)
    if deleted:
        await update.message.reply_text(f"✅ **Đã xóa Key thành công:** `{target_key}`", parse_mode="Markdown")
    else:
        await update.message.reply_text(f"❌ **Không tìm thấy Key:** `{target_key}`", parse_mode="Markdown")


async def cmd_listkey(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Xem danh sách toàn bộ key bản quyền"""
    user_id = update.effective_user.id
    if user_id != ADMIN_ID:
        await update.message.reply_text("❌ **Bạn không có quyền Admin để xem danh sách Key!**", parse_mode="Markdown")
        return

    keys = key_manager.list_keys()
    if not keys:
        await update.message.reply_text("📭 **Hiện chưa có Key nào trong hệ thống!** Dùng `/taokey` để tạo.", parse_mode="Markdown")
        return

    text = f"📋 **DANH SÁCH KEY BẢN QUYỀN ({len(keys)} KEY):**\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    for k in keys:
        text += key_manager.format_key_info(k) + "\n"

    await update.message.reply_text(text, parse_mode="Markdown")


async def cmd_regacc(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Tự động tạo acc và nạp thẳng vào kho API Visit & SpamKB"""
    count = 3
    if ctx.args:
        try:
            count = int(ctx.args[0])
            if count < 1: count = 1
            if count > 20: count = 20
        except ValueError:
            count = 3

    msg = await update.message.reply_text(
        f"⚡ **ĐANG TỰ ĐỘNG TẠO {count} TÀI KHOẢN KHÁCH & NẠP LÊN API VISIT...**\n"
        "• Khởi tạo OAuth Garena ➔ Nhận diện MSDK\n"
        "• Đăng ký nhân vật ➔ Lấy token & lưu `accounts.json`\n"
        "• Đồng bộ trực tiếp vào Session Pool của API Visit!\n"
        "⏳ Vui lòng chờ vài giây...",
        parse_mode="Markdown"
    )

    def _worker(n):
        res = []
        for _ in range(n):
            try:
                acc = create_full_vn_guest_account("KimQuynh")
                if acc:
                    res.append(acc)
            except Exception as e:
                print(f"[regacc error]: {e}")
        return res

    created = await asyncio.to_thread(_worker, count)
    if not created:
        await msg.edit_text("❌ **Tạo tài khoản thất bại!** Vui lòng thử lại sau.", parse_mode="Markdown")
        return

    accs = load_accounts()
    for acc in created:
        accs = [a for a in accs if str(a.get("uid")) != str(acc["uid"])]
        accs.append({"uid": str(acc["uid"]), "password": str(acc["password"])})
    save_accounts(accs)

    text = (
        f"🎉 **ĐÃ TẠO VÀ ĐỒNG BỘ THÀNH CÔNG {len(created)}/{count} TÀI KHOẢN LÊN API VISIT!**\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    )
    for idx, a in enumerate(created, 1):
        text += f"{idx}. 👤 `{a.get('name')}` | In-Game: `{a.get('account_id')}` | UID: `{a.get('uid')}`\n"

    text += (
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"📦 **Tổng tài khoản đang hoạt động trong kho:** **{len(accs)} acc**\n"
        "✨ **Tất cả tài khoản mới đã sẵn sàng phục vụ API `/api?visit=...` và `/api?spamkb=...` ngay lập tức!**"
    )
    await msg.edit_text(text, parse_mode="Markdown")


async def cmd_seturl(update: Update, ctx: ContextTypes.DEFAULT_TYPE):
    """Cài đặt link web Render để tự động ping mỗi 5 phút chống ngủ đông 24/24"""
    if not ctx.args:
        saved_url = None
        if os.path.exists(APP_URL_FILE):
            try:
                with open(APP_URL_FILE, "r", encoding="utf-8") as f:
                    saved_url = f.read().strip()
            except Exception:
                pass
        curr_str = f"`{saved_url}`" if saved_url else "*Chưa cài đặt*"
        text = (
            "⚙️ **CÀI ĐẶT TỰ ĐỘNG PING CHỐNG NGỦ ĐÔNG RENDER (5 PHÚT/LẦN):**\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 **Link Web hiện tại:** {curr_str}\n\n"
            "💡 **Cách dùng:** Gõ lệnh kèm theo link Render của bạn:\n"
            "👉 `/seturl https://ten-app-cua-ban.onrender.com`\n\n"
            "✨ *Bot và Web sẽ tự động gửi request đến web cứ mỗi 5 phút để server hoạt động 24/24 không bao giờ ngủ đông!*"
        )
        await update.message.reply_text(text, parse_mode="Markdown")
        return

    url = ctx.args[0].strip().rstrip("/")
    if not url.startswith("http://") and not url.startswith("https://"):
        url = "https://" + url

    try:
        with open(APP_URL_FILE, "w", encoding="utf-8") as f:
            f.write(url)
    except Exception as e:
        await update.message.reply_text(f"❌ Lỗi ghi file: {e}")
        return

    msg = await update.message.reply_text(f"⏳ **Đang ping thử tới `{url}/healthz`...**", parse_mode="Markdown")
    try:
        r = await asyncio.to_thread(requests.get, f"{url}/healthz", timeout=10)
        status_ok = r.status_code == 200
    except Exception as ex:
        status_ok = False

    if status_ok:
        text = (
            "🎉 **ĐÃ CÀI ĐẶT TỰ ĐỘNG PING CHỐNG NGỦ ĐÔNG THÀNH CÔNG!**\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 **Target URL:** `{url}/healthz`\n"
            "⏱️ **Tần suất:** Tự động gửi request mỗi **5 phút** một lần\n"
            "🟢 **Kết quả kiểm tra:** `200 OK` (Web đang hoạt động hoàn hảo)\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            "✨ **Từ bây giờ Web Service & Telegram Bot trên Render sẽ luôn thức 24/24 không bao giờ bị Sleep!**"
        )
    else:
        text = (
            "⚠️ **ĐÃ LƯU LINK THÀNH CÔNG:**\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
            f"🌐 **Target URL:** `{url}/healthz`\n"
            "⏱️ Hệ thống sẽ tự động gửi request mỗi **5 phút** một lần.\n"
            "💡 *Khi Web Service trên Render Deploy hoàn tất, hệ thống sẽ tự động giữ kết nối 24/24!*"
        )
    await msg.edit_text(text, parse_mode="Markdown")


def build_bot_app():
    req = HTTPXRequest(connection_pool_size=10, read_timeout=30.0, write_timeout=30.0, connect_timeout=30.0)
    app = Application.builder().token(BOT_TOKEN).request(req).build()
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("help", cmd_help))
    app.add_handler(CommandHandler("team5", cmd_team5))
    app.add_handler(CommandHandler("invite", cmd_invite))
    app.add_handler(CommandHandler("visit", cmd_visit))
    app.add_handler(CommandHandler("spamkb", cmd_spamkb))
    app.add_handler(CommandHandler("kb", cmd_kb))
    app.add_handler(CommandHandler("evo", cmd_evo))
    app.add_handler(CommandHandler("stop", cmd_stop))
    app.add_handler(CommandHandler("reg", cmd_reg))
    app.add_handler(CommandHandler("regacc", cmd_regacc))
    app.add_handler(CommandHandler("regauto", cmd_regauto))
    app.add_handler(CommandHandler("accs", cmd_accs))
    app.add_handler(CommandHandler("check", cmd_check))
    app.add_handler(CommandHandler("taokey", cmd_taokey))
    app.add_handler(CommandHandler("xoakey", cmd_xoakey))
    app.add_handler(CommandHandler("listkey", cmd_listkey))
    app.add_handler(CommandHandler("seturl", cmd_seturl))
    return app

def main():
    if not BOT_TOKEN or BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
        print("❌ LỖI: Chưa có BOT_TOKEN!")
        return

    print("=" * 60)
    print("🤖 HAKURA2 FF TELEGRAM BOT (FULL AUTOMATION EDITION) READY")
    print(f"   • Workdir  : {BASE_DIR}")
    print(f"   • Python   : {TERMUX_PYTHON}")
    print(f"   • Bot Token: {BOT_TOKEN[:10]}...***")
    print(f"   • Accounts : {ACCOUNTS_FILE}")
    print("=" * 60)

    print("🚀 Bot đang chạy... (Nhấn Ctrl+C để dừng)")
    while True:
        try:
            app = build_bot_app()
            app.run_polling(drop_pending_updates=True, bootstrap_retries=-1)
            break
        except KeyboardInterrupt:
            print("\n[!] Dừng Bot.")
            break
        except Exception as e:
            print(f"[!] Lỗi kết nối Telegram: {e} -> Tự tạo lại app và kết nối sau 5s...")
            time.sleep(5)

if __name__ == "__main__":
    main()
