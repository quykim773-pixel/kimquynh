import requests
import json
import threading
import time
import os
import sys
import urllib3
from datetime import datetime
from pyfiglet import figlet_format

# ================================================================
# COLOR CODES FOR TERMUX TERMINAL
# ================================================================
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    WARNING = '\033[93m'
    FAIL = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

try:
    from byte import Encrypt_ID, encrypt_api
except ImportError:
    def Encrypt_ID(uid: str) -> str:
        return uid.encode().hex()
    def encrypt_api(payload: str) -> str:
        return payload.encode().hex()

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

REGION_MAP = {
    "ind": "https://client.ind.freefiremobile.com",
    "me": "https://clientbp.ggblueshark.com",
    "vn": "https://clientbp.ggpolarbear.com",
    "bd": "https://clientbp.ggwhitehawk.com",
    "pk": "https://clientbp.ggblueshark.com",
    "sg": "https://clientbp.ggpolarbear.com",
    "br": "https://client.us.freefiremobile.com",
    "na": "https://client.us.freefiremobile.com",
    "id": "https://clientbp.ggpolarbear.com",
    "ru": "https://clientbp.ggpolarbear.com",
    "th": "https://clientbp.ggpolarbear.com",
}

ALL_REGIONS = list(REGION_MAP.items())

def banner():
    os.system('clear' if os.name == 'posix' else 'cls')
    print(f"{Colors.CYAN}")
    print(figlet_format("SEXTYMODS", font="slant"))
    print(f"{Colors.WARNING}>> FF Friend Request Tool <<{Colors.ENDC}")
    print(f"{Colors.GREEN}>> Version : OB55<<{Colors.ENDC}")

def send_friend_request(target_uid, token, region_server_url):
    try:
        encrypted_id = Encrypt_ID(target_uid)
        payload = f"08a7c4839f1e10{encrypted_id}1801"
        encrypted_payload = encrypt_api(payload)
        url = f"{region_server_url}/RequestAddingFriend"
        headers = {
            "Expect": "100-continue",
            "Authorization": f"Bearer {token}",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": "OB55",
            "Content-Type": "application/x-www-form-urlencoded",
            "Content-Length": str(len(encrypted_payload)//2),
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 9; SM-N975F Build/PI)",
            "Connection": "close",
            "Accept-Encoding": "gzip, deflate, br"
        }
        response = requests.post(url, headers=headers, data=bytes.fromhex(encrypted_payload), timeout=15)
        resp_text = response.text[:200]
        if response.status_code == 200:
            if "Invalid request body" in resp_text:
                return False, f"200 OK but body: {resp_text}"
            return True, "Success"
        else:
            return False, f"HTTP {response.status_code}"
    except Exception as e:
        return False, str(e)

def process_request(target_uid, token, regions_to_try, index, results):
    success = False
    for region_name, server_url in regions_to_try:
        ok, resp_msg = send_friend_request(target_uid, token, server_url)
        if ok:
            success = True
            break
            
    if success:
        print(f"{Colors.GREEN}[+] Friend Request Sent Successfully!{Colors.ENDC}")
        results['successful_count'] += 1
    else:
        print(f"{Colors.FAIL}[-] Friend Request Failed.{Colors.ENDC}")
        results['failed_count'] += 1

def main():
    banner()
    
    target_uid = input(f"{Colors.CYAN}[?] Enter Target UID: {Colors.ENDC}").strip()
    if not target_uid:
        print(f"{Colors.FAIL}[-] UID cannot be empty!{Colors.ENDC}")
        sys.exit(1)
        
    jwt_token = input(f"{Colors.CYAN}[?] Enter your JWT Token: {Colors.ENDC}").strip()
    if not jwt_token:
        print(f"{Colors.FAIL}[-] JWT Token cannot be empty!{Colors.ENDC}")
        sys.exit(1)
        
    region_input = input(f"{Colors.CYAN}[?] Enter Region Code (e.g., ind, br, or leave blank for all): {Colors.ENDC}").strip()
    region = region_input if region_input else None

    if region:
        region_lower = region.lower()
        if region_lower in REGION_MAP:
            regions_to_try = [(region_lower, REGION_MAP[region_lower])]
        else:
            print(f"{Colors.FAIL}[-] Invalid region. Defaulting to all regions.{Colors.ENDC}")
            regions_to_try = ALL_REGIONS
    else:
        regions_to_try = ALL_REGIONS

    print(f"\n{Colors.BOLD}[*] Starting request for Target UID: {target_uid}{Colors.ENDC}\n" + "-"*50)

    results = {
        "successful_count": 0,
        "failed_count": 0
    }
    
    # Executes only 1 time
    process_request(target_uid, jwt_token, regions_to_try, 0, results)
        
    print("\n" + "="*50)
    print(f"{Colors.HEADER}[+] PROCESS COMPLETED{Colors.ENDC}")
    print(f"{Colors.GREEN}    Successful Requests : {results['successful_count']}{Colors.ENDC}")
    print(f"{Colors.FAIL}    Failed Requests     : {results['failed_count']}{Colors.ENDC}")
    print("="*50)

if __name__ == "__main__":
    main()
