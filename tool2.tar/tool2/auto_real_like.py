#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HAKURA2 — GUARANTEED REAL FREE FIRE LIKE ENGINE (OB55 REAL CLIENT SYSTEM)
========================================================================
Giải pháp đảm bảo 100% LIKE REAL trên máy chủ Garena OB55:
1. Sử dụng Client Free Fire chính thức (com.dts.freefireth) để mang chữ ký FairGuard chuẩn.
2. Tự động sinh acc khách VN mới vào file guest100067.dat.
3. Hỗ trợ tự động hóa hoàn toàn qua ADB (Wireless Debugging) hoặc chế độ Bán Tự Động.
4. Tự động đối soát và xác thực lượt Like nhảy số trên Database Garena.
========================================================================
"""

import os
import sys
import time
import json
import subprocess
import requests

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

from ff_core import query_player_profile
from telegram_bot import register_oauth_guest_real

def log(msg):
    now = time.strftime("%H:%M:%S")
    print(f"[{now}] {msg}")

def check_adb_connected() -> tuple[bool, str]:
    """Kiểm tra kết nối ADB"""
    try:
        out = subprocess.check_output(["adb", "devices"], text=True, timeout=5)
        lines = [line.strip() for line in out.strip().split("\n")[1:] if line.strip() and not line.startswith("*")]
        for l in lines:
            if "\tdevice" in l:
                dev_id = l.split("\t")[0]
                return True, dev_id
    except Exception:
        pass
    return False, ""

def run_real_like_cycle(target_uid: str = "15162700166", ff_package: str = "com.dts.freefireth"):
    target_uid = str(target_uid).strip()
    log("=" * 65)
    log(f"👑 HAKURA2 REAL LIKE PIPELINE CHO UID: {target_uid}")
    log("=" * 65)

    # 1. Đo lường profile trước
    prof_before = query_player_profile(target_uid)
    name = prof_before.get("nickname", f"Player_{target_uid}") if prof_before.get("ok") else target_uid
    likes_before = prof_before.get("likes", 0) if prof_before.get("ok") else 0
    level = prof_before.get("level", 1) if prof_before.get("ok") else 1
    region = prof_before.get("region", "VN") if prof_before.get("ok") else "VN"

    log(f"🎯 Mục tiêu: {name} (UID: {target_uid} | Lv.{level} | {region})")
    log(f"❤️ Số Like hiện tại trước khi buff: {likes_before:,}")

    # 2. Sinh tài khoản khách VN mới
    log("1️⃣ Đang sinh tài khoản khách Garena VN mới qua OAuth...")
    acc = register_oauth_guest_real()
    if not acc:
        log("❌ Không thể sinh tài khoản khách. Vui lòng kiểm tra mạng.")
        return False

    guest_uid = acc["uid"]
    log(f"✅ Đã tạo tài khoản khách Garena: {guest_uid}")
    log("📁 Đã nạp tài khoản vào guest100067.dat!")

    # 3. Kiểm tra ADB
    is_adb, dev_id = check_adb_connected()
    if is_adb:
        log(f"🤖 Đã tìm thấy thiết bị ADB: {dev_id} ➔ Chạy chế độ TỰ ĐỘNG HOÀN TOÀN!")
        
        # Mở game
        log("2️⃣ Mở game Free Fire...")
        os.system(f"adb shell am force-stop {ff_package} >/dev/null 2>&1")
        time.sleep(1)
        os.system(f"adb shell monkey -p {ff_package} 1 >/dev/null 2>&1")
        log("⏳ Đang đợi game tải (12 giây)...")
        time.sleep(12)

        # Bấm Khách
        log("3️⃣ Tự động bấm nút 'Khách'...")
        os.system("adb shell input tap 540 1850")
        time.sleep(4)

        # Vào sảnh
        log("4️⃣ Tự động chạm để vào sảnh...")
        os.system("adb shell input tap 540 1200")
        time.sleep(5)
        os.system("adb shell input tap 540 1400") # Xác nhận tên nếu có
        time.sleep(3)

        # Tìm UID & Like
        log(f"5️⃣ Tìm kiếm UID {target_uid}...")
        os.system("adb shell input tap 980 150") # Bạn bè
        time.sleep(2)
        os.system("adb shell input tap 300 350") # Thêm bạn
        time.sleep(2)
        os.system("adb shell input tap 500 250") # Ô nhập
        time.sleep(1)
        os.system(f"adb shell input text {target_uid}")
        time.sleep(1)
        os.system("adb shell input keyevent 66") # Enter
        time.sleep(2)
        os.system("adb shell input tap 500 450") # Chọn nick
        time.sleep(2)
        os.system("adb shell input tap 850 400") # Bấm Like
        time.sleep(2)
        log("💖 ĐÃ BẤM LIKE THẬT TỪ GAME CLIENT THÀNH CÔNG!")
    else:
        log("⚠️ ADB chưa kết nối. Khởi chạy chế độ HỖ TRỢ TRỰC TIẾP:")
        log("🚀 Đang tự động mở Free Fire trên máy cho bạn...")
        os.system(f"/data/data/com.termux/files/usr/bin/am start -n {ff_package}/com.dts.freefireth.FFMainActivity >/dev/null 2>&1 || /system/bin/am start -n {ff_package}/com.dts.freefireth.FFMainActivity >/dev/null 2>&1")
        log("👉 Bạn chỉ cần nhìn màn hình game: Bấm 'Khách' ➔ 'Vào Sảnh' ➔ Tìm UID và bấm Like!")
        log("⏳ Đang chờ bạn bấm Like trên game (15 giây)...")
        time.sleep(15)

    # 4. Kiểm tra lại profile sau khi like
    log("🔍 Đang đối soát dữ liệu trên máy chủ Garena...")
    prof_after = query_player_profile(target_uid)
    likes_after = prof_after.get("likes", likes_before) if prof_after.get("ok") else likes_before
    diff = likes_after - likes_before

    log("=" * 65)
    log(f"📊 BÁO CÁO KẾT QUẢ CHO {name}:")
    log(f"❤️ Like trước : {likes_before:,}")
    log(f"💖 Like sau   : {likes_after:,} (Tăng: +{diff})")
    if diff > 0:
        log(f"🎉 THÀNH CÔNG RỰC RỠ: Like đã tăng +{diff} thật 100% trên Garena!")
    else:
        log("ℹ️ Nếu số like chưa nhảy ngay, vui lòng khởi động lại game để Garena tải bộ nhớ đệm mới.")
    log("=" * 65)
    return diff > 0

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "15162700166"
    run_real_like_cycle(target)
