import requests
import json
import hmac
import hashlib
import time
import random
import urllib3
import ipaddress
import os
import sys
import threading
import re
import signal
import base64
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from datetime import datetime
import queue
from colorama import init, Fore, Back, Style

# Initialize Colorama
init(autoreset=True)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# ==================== SIGNAL HANDLER ====================
EXIT_FLAG = False

def signal_handler(sig, frame):
    global EXIT_FLAG
    print("\n\n⚠️ Stopping generation...")
    EXIT_FLAG = True
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)
signal.signal(signal.SIGTERM, signal_handler)

# ==================== CONSTANTS ====================
aes_key = bytes([89, 103, 38, 116, 99, 37, 68, 69, 117, 104, 54, 37, 90, 99, 94, 56])
aes_iv = bytes([54, 111, 121, 90, 68, 114, 50, 50, 69, 51, 121, 99, 104, 106, 77, 37])
HEX_KEY = "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3"
API_KEY = HEX_KEY.encode('utf-8')

# ==================== GLOBAL VARIABLES ====================
accounts_dict = {}
accounts_lock = threading.Lock()
success_count = 0
success_lock = threading.Lock()
fail_count = 0
fail_lock = threading.Lock()
save_queue = queue.Queue()
save_thread_running = True
selected_region = "VN"
base_name = "WJXAZ"
base_password = "TELE@WJXAZ"
account_count = 100
RARITY_SCORE_THRESHOLD = 8
RARE_COUNTER = 0
COUPLES_COUNTER = 0
COUPLES_DATA = {}
COUPLES_LOCK = threading.Lock()
start_time = 0

print_lock = threading.Lock()

# ==================== FOLDER & FILE LOCKS ====================
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
BASE_FOLDER = os.path.join(CURRENT_DIR, "DATA_ACCOUNTS")
ACCOUNTS_FOLDER = os.path.join(BASE_FOLDER, "ACCOUNTS")
RARE_ACCOUNTS_FOLDER = os.path.join(BASE_FOLDER, "RARE_ACCOUNTS")
COUPLES_ACCOUNTS_FOLDER = os.path.join(BASE_FOLDER, "COUPLES_ACCOUNTS")
TOKENS_FOLDER = os.path.join(BASE_FOLDER, "TOKENS_JWT")

for folder in [BASE_FOLDER, ACCOUNTS_FOLDER, RARE_ACCOUNTS_FOLDER, COUPLES_ACCOUNTS_FOLDER, TOKENS_FOLDER]:
    os.makedirs(folder, exist_ok=True)

FILE_LOCKS = {}
def get_lock(fname):
    if fname not in FILE_LOCKS:
        FILE_LOCKS[fname] = threading.Lock()
    return FILE_LOCKS[fname]

# ==================== RARE PATTERNS ====================
PATTERNS = {
    "R4": [r"(\d)\1{3,}", 3],
    "R3": [r"(\d)\1\1(\d)\2\2", 2],
    "S5": [r"(12345|23456|34567|45678|56789)", 4],
    "S4": [r"(0123|1234|2345|3456|4567|5678|6789|9876|8765|7654|6543|5432|4321|3210)", 3],
    "P6": [r"^(\d)(\d)(\d)\3\2\1$", 5],
    "P4": [r"^(\d)(\d)\2\1$", 3],
    "SPH": [r"(69|420|1337|007)", 4],
    "SPM": [r"(100|200|300|400|500|666|777|888|999)", 2],
    "QD": [r"(1111|2222|3333|4444|5555|6666|7777|8888|9999|0000)", 4],
    "MH": [r"^(\d{2,3})\1$", 3],
    "MM": [r"(\d{2})0\1", 2],
    "GD": [r"1618|0618", 3]
}

# ==================== SUPPORTED REGIONS ====================
SUPPORTED_REGIONS = {
    "VN": "Vietnam"
}
REGION_LIST = list(SUPPORTED_REGIONS.items())

# ==================== IP ROTATOR ====================
class IPRotator:
    REGION_IP_CIDRS = {
        "VN": [
            "1.52.0.0/14", "14.160.0.0/11", "27.64.0.0/12", "113.160.0.0/12"
        ]
    }
    _cache = {}

    @classmethod
    def get_random_ip(cls, region="VN"):
        region = region.upper()
        if region not in cls._cache:
            cidrs = cls.REGION_IP_CIDRS.get(region, ["27.0.0.0/8"])
            hosts = []
            for cidr in cidrs:
                try:
                    net = ipaddress.ip_network(cidr, strict=False)
                    for _ in range(3):
                        ip_int = int(net.network_address) + random.randint(1, 2 ** (32 - net.prefixlen) - 2)
                        hosts.append(str(ipaddress.IPv4Address(ip_int)))
                except:
                    continue
            cls._cache[region] = hosts if hosts else [f"{random.randint(1,255)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(0,255)}"]
        return random.choice(cls._cache[region])

    @classmethod
    def get_ip_headers(cls, region="VN"):
        ip = cls.get_random_ip(region)
        return {
            'X-Forwarded-For': ip,
            'X-Real-IP': ip,
            'Client-IP': ip
        }

# ========================================================
# ADVANCED GENERATING LOGIC
# ========================================================
_B64_KEY = b'X1NUQVJf'
_ENC_STR = lambda s: "".join(chr(ord(c) ^ 0x0F) for c in s)
_GEN_RND = lambda l: ''.join(__import__('random').SystemRandom().choice(__import__('string').ascii_letters + __import__('string').digits) for _ in range(l))
_SECURE_PASS = lambda pfx: f"{pfx}{base64.b64decode(_B64_KEY).decode('utf-8')}{_GEN_RND(9)}"

def generate_random_capital_letters(length=4):
    return ''.join(random.choice('ABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(length))

def generate_exponent():
    exp_digits = {'0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹'}
    num = random.randint(1, 9999)
    return ''.join(exp_digits[d] for d in f"{num:04d}")

def generate_account_name(base_name):
    if base_name:
        return f"{base_name}{generate_exponent()}"
    else:
        prefixes = ["STARッ◇유", "STARRッ"]
        return f"{random.choice(prefixes)}~{generate_exponent()}"

def generate_password(base_password):
    try:
        if base_password:
            clean = base_password.split('WX')[0]
            return _SECURE_PASS(clean)
        else:
            return _SECURE_PASS("WX")
    except:
        clean = base_password.split('WX')[0] if base_password else "WX"
        return f"{clean}WX{_GEN_RND(8)}"
# ========================================================

# ==================== RARE / COUPLE DETECTORS ====================
def check_rarity(account_data):
    account_id = str(account_data.get("account_id", ""))
    if not account_id or account_id == "N/A":
        return False, None, None, 0
    score = 0
    patterns_found = []
    for ptype, (pattern, pts) in PATTERNS.items():
        if re.search(pattern, account_id):
            score += pts
            patterns_found.append(ptype)
    digits = [int(d) for d in account_id if d.isdigit()]
    if len(set(digits)) == 1 and len(digits) >= 4:
        score += 5
        patterns_found.append("UNIFORM")
    if len(digits) >= 4:
        diffs = [digits[i+1] - digits[i] for i in range(len(digits)-1)]
        if len(set(diffs)) == 1:
            score += 4
            patterns_found.append("ARITHMETIC")
    if len(account_id) <= 8 and account_id.isdigit() and int(account_id) < 1000000:
        score += 3
        patterns_found.append("LOW_ID")
    if score >= RARITY_SCORE_THRESHOLD:
        reason = f"ID:{account_id} | Score:{score} | {','.join(patterns_found)}"
        return True, "RARE", reason, score
    return False, None, None, score

def check_couple(account_data, thread_id):
    account_id = str(account_data.get("account_id", ""))
    if not account_id or account_id == "N/A":
        return False, None, None
    with COUPLES_LOCK:
        for stored_id, stored in COUPLES_DATA.items():
            stored_aid = str(stored.get('account_id', ''))
            if stored_aid and abs(int(account_id) - int(stored_aid)) == 1:
                partner = stored
                del COUPLES_DATA[stored_id]
                return True, f"Sequential: {account_id} & {stored_aid}", partner
            if stored_aid and account_id == stored_aid[::-1]:
                partner = stored
                del COUPLES_DATA[stored_id]
                return True, f"Mirror: {account_id} & {stored_aid}", partner
        COUPLES_DATA[account_id] = {
            'uid': str(account_data.get('uid', '')),
            'account_id': account_id,
            'name': str(account_data.get('name', '')),
            'password': str(account_data.get('password', '')),
            'region': str(account_data.get('region', '')),
            'thread_id': thread_id,
            'timestamp': datetime.now().isoformat()
        }
    return False, None, None

# ==================== SAVE / LOAD (ATOMIC, APPEND) ====================
def load_region_accounts(region):
    global accounts_dict
    filename = os.path.join(ACCOUNTS_FOLDER, f"accounts-{region}.json")
    accounts_dict[region] = []
    try:
        if os.path.exists(filename):
            with open(filename, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, list):
                    accounts_dict[region] = data
                    safe_print(f"✅ Loaded {len(data)} existing accounts for {region}")
                    return len(data)
    except Exception as e:
        safe_print(f"⚠️ Load error for {region}: {e}")
    return 0

def save_region_accounts(region):
    filename = os.path.join(ACCOUNTS_FOLDER, f"accounts-{region}.json")
    tmp = filename + ".tmp"
    with accounts_lock:
        data = accounts_dict.get(region, [])
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        os.replace(tmp, filename)
        return True
    except Exception as e:
        safe_print(f"❌ Save error for {region}: {e}")
        return False

def save_all_regions():
    for region in list(accounts_dict.keys()):
        if accounts_dict.get(region):
            save_region_accounts(region)

def queue_save():
    save_queue.put(True)

def save_worker():
    global save_thread_running
    while save_thread_running:
        try:
            item = save_queue.get(timeout=1)
            if item is None:
                break
            save_all_regions()
            save_queue.task_done()
        except queue.Empty:
            continue
        except Exception as e:
            safe_print(f"⚠️ Save worker error: {e}")

def account_exists(uid, region):
    with accounts_lock:
        for acc in accounts_dict.get(region, []):
            if str(acc.get('uid')) == str(uid) or str(acc.get('account_id')) == str(uid):
                return True
    return False

def get_next_count():
    global success_count
    with success_lock:
        success_count += 1
        return success_count

def safe_print(*args, **kwargs):
    with print_lock:
        print(*args, **kwargs)

# ==================== PRINT FUNCTIONS ====================
def print_rarity_found(account_data, rarity_type, reason, rarity_score):
    print(f"\n💎 RARE ACCOUNT FOUND!")
    print(f"🎯 Type: {str(rarity_type)}")
    print(f"⭐ Rarity Score: {str(rarity_score)}")
    print(f"👤 Name: {str(account_data.get('name', 'N/A'))}")
    print(f"🆔 UID: {str(account_data.get('uid', 'N/A'))}")
    print(f"🎮 Account ID: {str(account_data.get('account_id', 'N/A'))}")
    print(f"📝 Reason: {str(reason)}")
    print(f"🧵 Thread: {str(account_data.get('thread_id', 'N/A'))}")
    print(f"🌍 Region: {str(account_data.get('region', 'N/A'))}\n")

def print_couples_found(account1, account2, reason):
    print(f"\n💑 COUPLES ACCOUNT FOUND!")
    print(f"📝 Reason: {str(reason)}")
    print(f"👤 Account 1: {str(account1.get('name', 'N/A'))} (ID: {str(account1.get('account_id', 'N/A'))}) - Thread {str(account1.get('thread_id', 'N/A'))}")
    print(f"👤 Account 2: {str(account2.get('name', 'N/A'))} (ID: {str(account2.get('account_id', 'N/A'))}) - Thread {str(account2.get('thread_id', 'N/A'))}")
    print(f"🆔 UIDs: {str(account1.get('uid', 'N/A'))} & {str(account2.get('uid', 'N/A'))}")
    print(f"🌍 Region: {str(account1.get('region', 'N/A'))}\n")

def print_registration_status(count, total, name, uid, password, account_id, region):
    print(f"📝 Registration {str(count)}/{str(total)}")
    print(f"👤 Name: {str(name)}")
    print(f"🆔 UID: {str(uid)}")
    print(f"🎮 Account ID: {str(account_id)}")
    print(f"🔑 Password: {str(password)}")
    print(f"🌍 Region: {str(region)}")
    print()

# ==================== PROTOBUF FUNCTIONS ====================
def create_vr(N):
    if N < 0:
        return b''
    H = []
    while True:
        S = N & 0x7F
        N >>= 7
        if N:
            S |= 0x80
        H.append(S)
        if not N:
            break
    return bytes(H)

def create_variant(field_number, value):
    field_header = (field_number << 3) | 0
    return create_vr(field_header) + create_vr(value)

def create_length(field_number, value):
    field_header = (field_number << 3) | 2
    encoded = value.encode() if isinstance(value, str) else value
    return create_vr(field_header) + create_vr(len(encoded)) + encoded

def create_proto(fields):
    packet = bytearray()
    for field, value in fields.items():
        if isinstance(value, dict):
            nested = create_proto(value)
            packet.extend(create_length(field, nested))
        elif isinstance(value, int):
            packet.extend(create_variant(field, value))
        elif isinstance(value, (str, bytes)):
            packet.extend(create_length(field, value))
    return packet

def decode_varint(data, offset):
    result = 0
    shift = 0
    while offset < len(data):
        byte = data[offset]
        result |= (byte & 0x7F) << shift
        offset += 1
        if not (byte & 0x80):
            return result, offset
        shift += 7
    return None, offset

def decode_protobuf(data):
    result = {}
    offset = 0
    data_len = len(data)
    while offset < data_len:
        header, offset = decode_varint(data, offset)
        if header is None:
            break
        field_number = header >> 3
        wire_type = header & 0x7
        if wire_type == 0:
            value, offset = decode_varint(data, offset)
            if value is not None:
                result[field_number] = value
        elif wire_type == 2:
            length, offset = decode_varint(data, offset)
            if length is None:
                break
            value = data[offset:offset + length]
            offset += length
            try:
                result[field_number] = value.decode('utf-8')
            except:
                result[field_number] = value.hex()
        elif wire_type == 1:
            offset += 8
        elif wire_type == 3:
            offset += 4
        else:
            break
    return result

def encrypt_aes(hex_data):
    cipher = AES.new(aes_key, AES.MODE_CBC, aes_iv)
    return cipher.encrypt(pad(bytes.fromhex(hex_data), AES.block_size)).hex()

# ==================== DATADOME ANTI-BOT BYPASS ====================
DATADOME_DDK = "AE3F04AD3F0D3A462481A337485081"
DATADOME_SDK_VERSION = "1.13.9"
DATADOME_CLIENT_VERSION = "4.0.44"
PIXEL_UA = "GarenaMSDK/4.0.44(Pixel ;Android 10;en;US;app 1.132.1 2019121229;)"

def get_datadome_cookie(target_url, max_retries=3):
    for attempt in range(max_retries):
        try:
            timestamp_ms = str(int(time.time() * 1000))
            events = json.dumps([{"id": 1, "message": "response validation", "source": "sdk", "date": int(timestamp_ms)}])
            camera = json.dumps({"auth": "false", "info": "{}"})
            payload = (
                f"cid=&ddv={DATADOME_SDK_VERSION}&ddvc={DATADOME_CLIENT_VERSION}"
                f"&ddk={DATADOME_DDK}&request={requests.utils.quote(target_url, safe='')}"
                f"&os=Android&osr=10&osn=Q&osv=29"
                f"&ua={requests.utils.quote(PIXEL_UA, safe='')}"
                f"&screen_x=2328&screen_y=1080&screen_d=440"
                f"&events={requests.utils.quote(events, safe='')}"
                f"&camera={requests.utils.quote(camera, safe='')}"
                f"&mdl=Pixel&prd=sailfish&mnf=Google&dev=sailfish&hrd=msm8996"
                f"&fgp={requests.utils.quote('Google/sailfish/sailfish:10/NHG47O/eng.build.20231013.013027:user/release-keys', safe='')}"
                f"&tgs=release-keys&inte=android-java-okhttp"
            )
            headers = {
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept-Encoding": "gzip",
                "User-Agent": "okhttp/4.12.0",
            }
            response = requests.post(
                "https://api-sdk.datadome.co/sdk/",
                headers=headers,
                data=payload,
                verify=False,
                timeout=15
            )
            if response.status_code == 200:
                json_data = response.json()
                cookie_full = json_data.get("cookie", "")
                if cookie_full and "datadome=" in cookie_full:
                    datadome_val = cookie_full.split(";")[0]
                    return datadome_val
            time.sleep(1)
        except Exception as e:
            safe_print(f"⚠️ DataDome attempt {attempt+1} failed: {e}")
            time.sleep(1)
    return None

# ==================== ACCOUNT API FUNCTIONS (UPDATED FOR OB55) ====================
def register_account(password, region):
    url = "https://100067.connect.garena.com/api/v2/oauth/guest:register"
    ip_headers = IPRotator.get_ip_headers(region)
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    payload_json = {"app_id": 100067, "client_type": 2, "password": password_hash, "source": 2}
    payload = json.dumps(payload_json, separators=(',', ':'))
    signature = hmac.new(API_KEY, payload.encode(), hashlib.sha256).hexdigest()
    timestamp = str(int(time.time() * 1000) + random.randint(-999, 999))
    headers = {
        "User-Agent": PIXEL_UA,
        "Authorization": f"Signature {signature}",
        "Content-Type": "application/json; charset=utf-8",
        "Accept": "application/json",
        "Connection": "Keep-Alive",
        "Host": "100067.connect.garena.com",
        "X-Garena-Timestamp": timestamp,
        **ip_headers
    }
    try:
        response = requests.post(url, headers=headers, data=payload, verify=False, timeout=30)
        if response.status_code == 200:
            json_data = response.json()
            if json_data.get("code") == 0 and "data" in json_data:
                uid = json_data["data"]["uid"]
                return str(uid), str(password)
            safe_print(f"  ↳ Register error: {json_data}")
        else:
            safe_print(f"  ↳ Register HTTP {response.status_code}: {response.text[:200]}")
        return None, None
    except Exception as e:
        safe_print(f"  ↳ Register exception: {e}")
        return None, None

def get_access_token(uid, password, region, device_id=None):
    url = "https://100067.connect.garena.com/api/v2/oauth/guest/token:grant"
    ip_headers = IPRotator.get_ip_headers(region)
    password_hash = hashlib.sha256(password.encode()).hexdigest()
    if not device_id:
        device_id = device_id_generate("", region)
    headers = {
        "Host": "100067.connect.garena.com",
        "User-Agent": PIXEL_UA,
        "Content-Type": "application/json; charset=utf-8",
        "Accept": "application/json",
        "Accept-Encoding": "gzip, deflate",
        "Connection": "close",
        **ip_headers
    }
    data = {
        "client_id": 100067,
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_type": 2,
        "device_id": device_id,
        "password": password_hash,
        "response_type": "token",
        "uid": int(uid)
    }
    try:
        response = requests.post(url, headers=headers, json=data, verify=False, timeout=30)
        if response.status_code == 200:
            json_data = response.json()
            if json_data.get("code") == 0 and "data" in json_data:
                d = json_data["data"]
                access_token = d.get("access_token")
                open_id = d.get("open_id")
                platform = d.get("platform")
                platform_type = int(platform) if platform else 4
                return access_token, open_id, platform_type
            safe_print(f"  ↳ TokenGrant error: {json_data}")
        else:
            safe_print(f"  ↳ TokenGrant HTTP {response.status_code}: {response.text[:200]}")
        return None, None, None
    except Exception as e:
        safe_print(f"  ↳ TokenGrant exception: {e}")
        return None, None, None

def device_id_generate(open_id, region):
    url = "https://100067.msdk.garena.com/device/api/v1/android/device-id:generate"
    ip_headers = IPRotator.get_ip_headers(region)
    payload_json = {
        "app_id": 100067,
        "data": {
            "ad_aaid": "",
            "android_id": "01b05346c944b5e6",
            "android_version_release": "10",
            "android_version_sdk": "29",
            "brand": "Google",
            "build_date": "1697185398000",
            "build_display": "NHG47O release-keys",
            "build_id": "NHG47O",
            "cpu_abis": "arm64-v8a,armeabi-v7a,armeabi",
            "drm_id": "",
            "drm_vendor": "",
            "fingerprint": "Google/sailfish/sailfish:10/NHG47O/eng.build.20231013.013027:user/release-keys",
            "gcbooster_uuid": "",
            "hardware": "msm8996",
            "imei": "",
            "model": "Pixel",
            "key_mqs_uuid": "",
            "product_name": "sailfish",
            "random_uuid": str(__import__('uuid').uuid4()),
            "soc_manufacturer": "",
            "soc_model": ""
        }
    }
    payload = json.dumps(payload_json, separators=(',', ':'))
    signature = hmac.new(API_KEY, payload.encode(), hashlib.sha256).hexdigest()
    headers = {
        "User-Agent": PIXEL_UA,
        "Authorization": f"Signature {signature}",
        "Accept": "application/json",
        "Content-Type": "application/json; charset=utf-8",
        "Host": "100067.msdk.garena.com",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        **ip_headers
    }
    try:
        response = requests.post(url, headers=headers, data=payload, verify=False, timeout=30)
        if response.status_code == 200:
            json_data = response.json()
            if json_data.get("code") == 0:
                return json_data["data"].get("device_id", "")
        return ""
    except:
        return ""

def generate_nickname(open_id, region):
    url = "https://loginbp.ppmainecoonghj.com/GenerateNickname"
    ip_headers = IPRotator.get_ip_headers(region)
    payload_fields = {
        1: "en",
        2: open_id
    }
    proto_bytes = create_proto(payload_fields)
    proto_hex = proto_bytes.hex()
    payload = bytes.fromhex(encrypt_aes(proto_hex))
    x_ga_sv = str(int(time.time()))
    headers = {
        "Accept-Encoding": "gzip",
        "Authorization": "Bearer",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Expect": "100-continue",
        "Host": "loginbp.ppmainecoonghj.com",
        "ReleaseVersion": "OB55",
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "X-GA": "v1 1",
        "X-GA-SV": x_ga_sv,
        "X-Unity-Version": "2018.4.12f1",
        **ip_headers
    }
    try:
        response = requests.post(url, headers=headers, data=payload, verify=False, timeout=30)
        if response.status_code == 200:
            return response.text.strip()
        safe_print(f"  ↳ GenerateNickname HTTP {response.status_code}: {response.text[:200]}")
        return ""
    except Exception as e:
        safe_print(f"  ↳ GenerateNickname exception: {e}")
        return ""

def major_register(access_token, open_id, name, region, LANG='en'):
    url = "https://loginbp.ppmainecoonghj.com/MajorRegister"
    ip_headers = IPRotator.get_ip_headers(region)
    keystream = [0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37, 0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37,
                 0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30, 0x31, 0x37, 0x30, 0x30, 0x30, 0x30, 0x30, 0x32, 0x30]
    encoded_open_id = ""
    for i, ch in enumerate(open_id):
        encoded_open_id += chr(ord(ch) ^ keystream[i % len(keystream)])
    field14 = encoded_open_id.encode('latin1')
    field22 = bytes.fromhex('474752450101010067020000a6a42db7bc5516876af3d1ba4adc337bac558af092eb3757d59d65c9323bba42c6593a48b74f33b2b5b3dc45cbd7ac02040db58f394045be4835213e12c35e5566445a5224f39d205fcf91c0e6bec797e7b3968ac00e90d7500b5865828a9d6f2091c3070f5319a130748e407ed57e6638974670ac045631b3d08c310cf1256cebcf1aed2d97d177534603d1c95d9c5d698340e797e72aa7ecc67a33122e48b0dfda050a1649586aca5e979be1fd9d99f48cd8cf59630e0ff60f67d4ed2ec4e5e7475970449a6c06329009ee0ce2567892587675781a31e4bb2774403b2f78e9811df2cb397fa602572266747704c6258077910902eb7420bcb4ab743d1610cddba9019e7867aaad3aa7ba9b04968064a409b66733f9f78c566a25ff478cba37a2ffe23203d4b05bceef826f174b0be7912d19432cc759325251fa094d70693fb672d6f9e799284081b3adb541dd8f27ef80dcf1e7f0ff30f2fd976659457ce41e175a2d6301b777981ccc16b9a8247abaab8de0867836c27de0146fe4d0e1fd39b86ba51f0b58601cfcbd7f6f3451fe4184b26ed44ac2f6f7bb4ce5d9a80f88c2cbfe7553e5ab97c8b028ae16b4f70f037753b8c229a6e5e9038fcbb9b4c2abb954894f8f2faf177bfdaab3b0ed537156633621d16b62d58ba4ebe518997c33e2304976ba6af9df7e7e34302c7910ae559c7e3d20a30d71c14f85c0e86f26291bbf18c2d9dfe9a908592eea4523e6c1e5d9bb5abfbebfccd5c4e136f9be777723e932b06c029df5125191000c90fde62a8e5f8fceb28648f0c69ec3037d09302b2ade908a20dbd42761ca449b2743fc362649e16235769d9fbd7f87cd64972b58d69c0441abb5d22ddc6ed059f7ac1bdbfaef8c60e64631809c5e08c7cb4074c8ce6170d94b411604986be4ae163a')
    payload_fields = {
        1: name,
        2: access_token,
        3: open_id,
        5: 102000007,
        6: 4,
        7: 1,
        13: 1,
        14: field14,
        15: LANG,
        16: 1,
        17: 1,
        20: "1.132.6",
        21: 1,
        22: field22
    }
    proto_bytes = create_proto(payload_fields)
    proto_hex = proto_bytes.hex()
    payload = bytes.fromhex(encrypt_aes(proto_hex))
    x_ga_sv = str(int(time.time()))
    headers = {
        "Accept-Encoding": "gzip",
        "Authorization": "Bearer",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Expect": "100-continue",
        "Host": "loginbp.ppmainecoonghj.com",
        "ReleaseVersion": "OB55",
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "X-GA": "v1 1",
        "X-GA-SV": x_ga_sv,
        "X-Unity-Version": "2018.4.12f1",
        **ip_headers
    }
    try:
        response = requests.post(url, headers=headers, data=payload, verify=False, timeout=30)
        if response.status_code == 200:
            return decode_protobuf(response.content)
        safe_print(f"  ↳ MajorRegister HTTP {response.status_code}: {response.text[:200]}")
        return {}
    except Exception as e:
        safe_print(f"  ↳ MajorRegister exception: {e}")
        return {}

def choose_newbie_choice(account_id, region):
    url = "https://loginbp.ppmainecoonghj.com/ChooseNewbieChoice"
    ip_headers = IPRotator.get_ip_headers(region)
    if not account_id:
        safe_print(f"  ↳ ChooseNewbieChoice: empty account_id, skipping")
        return False
    payload_fields = {
        1: int(account_id),
        2: 1,
        3: 3
    }
    proto_bytes = create_proto(payload_fields)
    proto_hex = proto_bytes.hex()
    payload = bytes.fromhex(encrypt_aes(proto_hex))
    x_ga_sv = str(int(time.time()))
    headers = {
        "Accept-Encoding": "gzip",
        "Authorization": "Bearer",
        "Connection": "Keep-Alive",
        "Content-Type": "application/x-www-form-urlencoded",
        "Expect": "100-continue",
        "Host": "loginbp.ppmainecoonghj.com",
        "ReleaseVersion": "OB55",
        "User-Agent": "UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)",
        "X-GA": "v1 1",
        "X-GA-SV": x_ga_sv,
        "X-Unity-Version": "2018.4.12f1",
        **ip_headers
    }
    try:
        response = requests.post(url, headers=headers, data=payload, verify=False, timeout=30)
        return response.status_code == 200
    except Exception as e:
        safe_print(f"  ↳ ChooseNewbieChoice exception: {e}")
        return False

def major_login_payload(access_token, open_id, platform_type):
    fields = {
        3: str(datetime.now())[:-7],
        4: "free fire",
        5: 1,
        7: "1.132.6",
        8: "Android OS 10 / API-29 (NHG47O/eng.build.20231013.013027)",
        9: "Handheld",
        10: "TelKila",
        11: "WIFI",
        12: 1708,
        13: 750,
        14: "440",
        15: "ARM64 FP ASIMD AES | 2850 | 8",
        16: 3968,
        17: "Mali-G610 MC6",
        18: "OpenGL ES 3.2 v1.r32p1-01eac0.54329dee8f160f288c574caaf67bbe3f",
        19: "Google|0ecc7b3b-6c41-462e-9050-26d835e84c53",
        20: "116.97.105.60",
        21: "en",
        22: open_id,
        23: str(platform_type),
        24: "Handheld",
        25: "Google Pixel",
        26: "SG",
        29: access_token,
        30: 1,
        41: "TelKila",
        42: "WIFI",
        57: "7428b253defc164018c604a1ebbfebdf",
        60: 109029,
        61: 37616,
        62: 2048,
        63: 804,
        64: 37616,
        65: 109029,
        66: 37616,
        67: 109029,
        73: 3,
        74: "/data/app/com.dts.freefireth-oiglMJkEoNJlsRci10280Q==/lib/arm64",
        76: 1,
        77: "b8e0cd5e295eee42f5860d3c86e483dd|/data/app/com.dts.freefireth-oiglMJkEoNJlsRci10280Q==/base.apk",
        78: 3,
        79: 2,
        81: "64",
        83: "2019121229",
        85: 3,
        86: "OpenGLES2",
        87: 511,
        88: platform_type,
        92: 36711,
        93: "android",
        94: "KqsHT8at0g7Na/G7iOeF1IpesHMf+HoePFMFFE8Tq/dSk4fIbJ1j8TdV8OAyWIVnSmD2rM6vfFMtCD8Ig7iROgDJmIMrdtcB6orwuNRpMr4MVu3D7FoTcuQdq/8EyOkRQiUrbg==",
        96: '{"cur_rate":null,"support_etc2":false}',
        97: 1,
        99: f"{platform_type}",
        100: f"{platform_type}",
        102: bytes.fromhex('4000434f07555f0637'),
        104: 1797,
        105: 1,
        106: "https://dl.cdn.freefiremobile.com/live/ABHotUpdates/|https://dl-core.cdn.freefiremobile.com/live/ABHotUpdates/|4a0070ac356973792f002e0b25b96c3b",
        107: "c8e41b7a93f02d56e1a94c7b8203f5d1"
    }
    pyl = create_proto(fields).hex()
    payload = bytes.fromhex(encrypt_aes(pyl))
    return payload

def _decode_varint(data, offset):
    result = 0
    shift = 0
    while offset < len(data):
        byte = data[offset]
        result |= (byte & 0x7F) << shift
        offset += 1
        shift += 7
        if not (byte & 0x80):
            return result, offset
    return None, offset


def _extract_field8_jwt(raw):
    o = 0
    while o < len(raw) - 1:
        idx = raw.find(b"\x42", o)
        if idx < 0:
            break
        length, after = _decode_varint(raw, idx + 1)
        if length is None:
            o = idx + 1
            continue
        end = after + length
        if end <= len(raw) and raw[after:after + 3] == b"eyJ":
            return raw[after:end]
        o = idx + 1
    return None


def major_login(payload, region):
    url = "https://loginbp.ppmainecoonghj.com/MajorLogin"
    ip_headers = IPRotator.get_ip_headers(region)
    x_ga_sv = str(int(time.time()))
    headers = {
        'X-Unity-Version': '2018.4.12f1',
        'ReleaseVersion': 'OB55',
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': 'Bearer',
        'Accept': '*/*',
        'Expect': '100-continue',
        'X-GA': 'v1 1',
        'X-GA-SV': x_ga_sv,
        'User-Agent': 'UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)',
        'Host': 'loginbp.ppmainecoonghj.com',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'deflate, gzip',
        **ip_headers
    }
    try:
        response = requests.post(url, headers=headers, data=payload, verify=False, timeout=30)
        if response.status_code == 200:
            raw = response.content
            jwt_bytes = _extract_field8_jwt(raw)
            if jwt_bytes is None:
                text = response.text
                jwt_start = text.find("eyJ")
                if jwt_start != -1:
                    jwt = text[jwt_start:]
                    dot2 = jwt.find(".", jwt.find(".") + 1)
                    if dot2 != -1:
                        jwt_bytes = jwt[:dot2 + 44].encode('utf-8', 'replace')
            if jwt_bytes:
                login_token = jwt_bytes.decode('utf-8', 'replace')
                account_id = ""
                try:
                    parts = login_token.split('.')
                    if len(parts) >= 2:
                        p = parts[1] + '=' * ((4 - len(parts[1]) % 4) % 4)
                        jd = json.loads(base64.urlsafe_b64decode(p))
                        account_id = str(jd.get('account_id', ''))
                except:
                    pass
                server_url = "https://clientbp.ppmainecoonghj.com"
                return {"login_token": login_token, "account_id": account_id, "server_url": server_url}
            safe_print(f"  ↳ MajorLogin: JWT not found in response")
            return {}
        safe_print(f"  ↳ MajorLogin HTTP {response.status_code}: {response.text[:200]}")
        return {}
    except Exception as e:
        safe_print(f"  ↳ MajorLogin exception: {e}")
        return {}

def get_login_data_payload(access_token, open_id, platform_type):
    fields = {
        3: str(datetime.now())[:-7],
        4: "free fire",
        5: 1,
        7: "1.132.6",
        8: "Android OS 10 / API-29 (NHG47O/eng.build.20231013.013027)",
        9: "Handheld",
        10: "TelKila",
        11: "WIFI",
        12: 1708,
        13: 750,
        14: "440",
        15: "ARM64 FP ASIMD AES | 2850 | 8",
        16: 3968,
        17: "Mali-G610 MC6",
        18: "OpenGL ES 3.2 v1.r32p1-01eac0.54329dee8f160f288c574caaf67bbe3f",
        19: "Google|0ecc7b3b-6c41-462e-9050-26d835e84c53",
        20: "116.97.105.60",
        21: "en",
        22: open_id,
        23: str(platform_type),
        24: "Handheld",
        25: "Google Pixel",
        26: "SG",
        29: access_token,
        30: 1,
        41: "TelKila",
        42: "WIFI",
        57: "7428b253defc164018c604a1ebbfebdf",
        60: 109029,
        61: 37616,
        62: 2048,
        63: 804,
        64: 37616,
        65: 109029,
        66: 37616,
        67: 109029,
        73: 3,
        74: "/data/app/com.dts.freefireth-oiglMJkEoNJlsRci10280Q==/lib/arm64",
        76: 1,
        77: "b8e0cd5e295eee42f5860d3c86e483dd|/data/app/com.dts.freefireth-oiglMJkEoNJlsRci10280Q==/base.apk",
        78: 3,
        79: 2,
        81: "64",
        83: "2019121229",
        85: 3,
        86: "OpenGLES2",
        87: 511,
        88: platform_type,
        90: bytes.fromhex('48e1baa3692044c6b0c6a16e67'),
        91: "61",
        92: 36711,
        93: "android",
        94: "KqsHT8at0g7Na/G7iOeF1IpesHMf+HoePFMFFE8Tq/dSk4fIbJ1j8TdV8OAyWIVnSmD2rM6vfFMtCD8Ig7iROgDJmIMrdtcB6orwuNRpMr4MVu3D7FoTcuQdq/8EyOkRQiUrbg==",
        96: '{"cur_rate":null,"support_etc2":false}',
        97: 1,
        99: "0",
        100: str(platform_type),
        102: bytes.fromhex('4000434f07555f0637'),
        103: 1,
        104: 1797,
        105: 1,
        106: "https://dl.cdn.freefiremobile.com/live/ABHotUpdates/|https://dl-core.cdn.freefiremobile.com/live/ABHotUpdates/|4a0070ac356973792f002e0b25b96c3b",
        107: "c8e41b7a93f02d56e1a94c7b8203f5d1"
    }
    pyl = create_proto(fields).hex()
    payload = bytes.fromhex(encrypt_aes(pyl))
    return payload

def get_login_data(server_url, jwt_token, payload, region):
    url = f"{server_url}/GetLoginData"
    ip_headers = IPRotator.get_ip_headers(region)
    x_ga_sv = str(int(time.time()))
    headers = {
        'X-Unity-Version': '2018.4.12f1',
        'ReleaseVersion': 'OB55',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-GA': 'v1 1',
        'X-GA-SV': x_ga_sv,
        'User-Agent': 'UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)',
        'Host': 'clientbp.ppmainecoonghj.com',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip',
        'Authorization': f'Bearer {jwt_token}',
        **ip_headers
    }
    try:
        response = requests.post(url, headers=headers, data=payload, verify=False, timeout=30)
        if response.status_code == 200:
            return decode_protobuf(response.content)
        safe_print(f"  ↳ GetLoginData HTTP {response.status_code}")
        return {}
    except Exception as e:
        safe_print(f"  ↳ GetLoginData exception: {e}")
        return {}

def clientbp_post(endpoint, server_url, jwt_token, payload, region):
    url = f"{server_url}/{endpoint}"
    ip_headers = IPRotator.get_ip_headers(region)
    x_ga_sv = str(int(time.time()))
    headers = {
        'X-Unity-Version': '2018.4.12f1',
        'ReleaseVersion': 'OB55',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-GA': 'v1 1',
        'X-GA-SV': x_ga_sv,
        'User-Agent': 'UnityPlayer/2018.4.12f1 (UnityWebRequest/1.0, libcurl/8.5.0-DEV)',
        'Host': 'clientbp.ppmainecoonghj.com',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip',
        'Authorization': f'Bearer {jwt_token}',
        **ip_headers
    }
    try:
        response = requests.post(url, headers=headers, data=payload, verify=False, timeout=30)
        if response.status_code == 200:
            return 200, decode_protobuf(response.content)
        safe_print(f"  ↳ {endpoint} HTTP {response.status_code}: {response.text[:150]}")
        return response.status_code, {}
    except Exception as e:
        safe_print(f"  ↳ {endpoint} exception: {e}")
        return -1, {}

def _encrypt_proto(fields):
    proto_bytes = create_proto(fields)
    return bytes.fromhex(encrypt_aes(proto_bytes.hex()))

def complete_login(server_url, jwt_token, access_token, open_id, account_id, region):
    endpoint_specs = [
        ("GetPlatformProfile", {1: access_token, 2: open_id, 3: 1}),
        ("GetPlayerPersonalShow", {1: int(account_id), 2: 9, 3: 1, 4: 1}),
        ("GetWorkshopSwitch", {}),
        ("GetFriend", {1: 1, 7: 1, 9: 1}),
        ("LoginGetProfile", {}),
        ("GetPlayerDailyCSRankingSummary", {}),
        ("GetPlayerDailyRankingSummary", {}),
        ("LoginGetAccountInfo", {1: "en", 2: 1, 3: 1}),
        ("LoginGetSplash", {1: "en", 2: 2, 3: 1}),
        ("LoginGetDesc", {1: "en", 2: 1, 3: "VN", 4: 1}),
        ("Ping", {}),
    ]
    ok = 0
    for endpoint, fields in endpoint_specs:
        payload = _encrypt_proto(fields)
        status, decoded = clientbp_post(endpoint, server_url, jwt_token, payload, region)
        if status == 200:
            ok += 1
            safe_print(f"  ✓ {endpoint}: HTTP 200 ({len(decoded)} fields)")
        else:
            safe_print(f"  ⚠ {endpoint}: HTTP {status}")
    return ok

# ==================== ACCOUNT CREATION (HAR-MATCHED OB55 FLOW) ====================
def create_full_account(thread_id, region, base_name, base_password, max_retries=2):
    global fail_count, RARE_COUNTER, COUPLES_COUNTER, EXIT_FLAG, account_count
    if EXIT_FLAG:
        return None

    for attempt in range(max_retries):
        try:
            t_start = time.time()
            password = generate_password(base_password)
            name = generate_account_name(base_name)

            safe_print(f"  → [T{thread_id}] Register (attempt {attempt+1})...")
            register_uid, password = register_account(password, region)
            if not register_uid:
                safe_print(f"❌ [T{thread_id}] Register failed (attempt {attempt+1})")
                time.sleep(0.5)
                continue

            safe_print(f"  → [T{thread_id}] Token grant (uid={register_uid})...")
            access_token, open_id, platform_type = get_access_token(register_uid, password, region)
            if not access_token:
                safe_print(f"❌ [T{thread_id}] Token grant failed (attempt {attempt+1})")
                time.sleep(0.5)
                continue
            safe_print(f"  → [T{thread_id}] Token OK open_id={open_id[:16]}... platform={platform_type} ({time.time()-t_start:.1f}s)")

            t0 = time.time()
            safe_print(f"  → [T{thread_id}] device_id_generate...")
            device_id_generate(open_id, region)

            safe_print(f"  → [T{thread_id}] first MajorLogin (expect 404)...")
            payload = major_login_payload(access_token, open_id, platform_type)
            major_login(payload, region)
            safe_print(f"  → [T{thread_id}] first MajorLogin done in {time.time()-t0:.1f}s")

            t1 = time.time()
            safe_print(f"  → [T{thread_id}] GenerateNickname...")
            nickname = generate_nickname(open_id, region)
            safe_print(f"  → [T{thread_id}] GenerateNickname done in {time.time()-t1:.1f}s nickname={nickname[:30] if nickname else 'EMPTY'}")
            if nickname:
                name = nickname

            t2 = time.time()
            safe_print(f"  → [T{thread_id}] MajorRegister(name={name[:20]})...")
            reg_response = major_register(access_token, open_id, name, region)
            safe_print(f"  → [T{thread_id}] MajorRegister done in {time.time()-t2:.1f}s response_keys={list(reg_response.keys()) if reg_response else 'EMPTY'}")
            if not reg_response:
                safe_print(f"❌ [T{thread_id}] MajorRegister failed (attempt {attempt+1})")
                time.sleep(0.5)
                continue

            account_id = ""
            if 3 in reg_response:
                account_id = str(reg_response[3])
            else:
                safe_print(f"❌ [T{thread_id}] MajorRegister: no account_id (attempt {attempt+1})")
                time.sleep(0.5)
                continue

            t3 = time.time()
            safe_print(f"  → [T{thread_id}] ChooseNewbieChoice(account_id={account_id})...")
            choose_newbie_choice(account_id, region)
            safe_print(f"  → [T{thread_id}] ChooseNewbieChoice done in {time.time()-t3:.1f}s")

            t4 = time.time()
            safe_print(f"  → [T{thread_id}] second MajorLogin (expect 200)...")
            payload = major_login_payload(access_token, open_id, platform_type)
            login_response = major_login(payload, region)
            safe_print(f"  → [T{thread_id}] second MajorLogin done in {time.time()-t4:.1f}s keys={list(login_response.keys()) if login_response else 'EMPTY'}")
            if not login_response or "login_token" not in login_response:
                safe_print(f"❌ [T{thread_id}] MajorLogin failed (attempt {attempt+1})")
                time.sleep(0.5)
                continue

            jwt_token = login_response["login_token"]
            account_id = login_response.get("account_id", "")
            server_url = login_response.get("server_url", "")

            if server_url:
                gld_payload = get_login_data_payload(access_token, open_id, platform_type)
                login_data = get_login_data(server_url, jwt_token, gld_payload, region)
                complete_login(server_url, jwt_token, access_token, open_id, account_id, region)

            if not account_exists(register_uid, region):
                count = get_next_count()

                account = {
                    'uid': str(register_uid),
                    'password': str(password),
                    'name': str(name),
                    'account_id': str(account_id),
                    'region': str(region),
                    'jwt_token': str(jwt_token),
                    'created_at': datetime.now().isoformat(),
                    'thread_id': str(thread_id)
                }

                with accounts_lock:
                    if region not in accounts_dict:
                        accounts_dict[region] = []
                    accounts_dict[region].append(account)

                queue_save()

                print_registration_status(count, account_count, name, register_uid, password, account_id, region)

                is_rare, rtype, reason, rscore = check_rarity(account)
                if is_rare:
                    with success_lock:
                        RARE_COUNTER += 1
                    print_rarity_found(account, rtype, reason, rscore)

                is_couple, creason, partner = check_couple(account, thread_id)
                if is_couple and partner:
                    with success_lock:
                        COUPLES_COUNTER += 1
                    print_couples_found(account, partner, creason)

                return account
            else:
                safe_print(f"⚠️ [T{thread_id}] Account already exists in {region}: {register_uid}")
                return None
        except Exception as e:
            safe_print(f"❌ [T{thread_id}] Error: {e}")
            time.sleep(1)
            continue

    with fail_lock:
        fail_count += 1
    return None

def worker(thread_id, region, base_name, base_password):
    global EXIT_FLAG, success_count, account_count
    while not EXIT_FLAG:
        try:
            with success_lock:
                if success_count >= account_count:
                    break
            create_full_account(thread_id, region, base_name, base_password)
            time.sleep(random.uniform(0.5, 1.0))
        except Exception as e:
            safe_print(f"⚠️ [T{thread_id}] Worker error: {e}")
            time.sleep(1)

# ==================== MENU FUNCTIONS ====================
def get_account_count():
    global account_count
    print("=" * 60)
    print("🎯 ACCOUNT COUNT")
    print("=" * 60)
    while True:
        try:
            cnt = input("Number of accounts to generate (default 100): ").strip()
            if not cnt:
                account_count = 100
                print("✅ Generating 100 accounts (default)")
                return 100
            cnt = int(cnt)
            if cnt > 0:
                account_count = cnt
                print(f"✅ Generating {cnt} accounts")
                return cnt
            else:
                print("❌ Enter positive number")
        except:
            print("❌ Invalid input! Using default 100")
            account_count = 100
            return 100

def get_thread_count():
    try:
        cpu = os.cpu_count() or 1
        recommended = min(cpu, 3)
    except:
        recommended = 3
    print("=" * 60)
    print("⚡ THREAD COUNT")
    print("=" * 60)
    print(f"💡 Recommended: {recommended} (based on CPU)")
    print(f"💡 Max 200 threads (with delays)")
    while True:
        try:
            cnt = input(f"Number of threads (default {recommended}): ").strip()
            if not cnt:
                print(f"✅ Using {recommended} threads")
                return recommended
            cnt = int(cnt)
            if 1 <= cnt <= 200:
                print(f"✅ Using {cnt} threads")
                return cnt
            else:
                print("❌ Enter 1-200")
        except:
            print(f"❌ Invalid input! Using default {recommended}")
            return recommended

def get_rarity_threshold():
    global RARITY_SCORE_THRESHOLD
    print("=" * 60)
    print("⭐ RARITY THRESHOLD")
    print("=" * 60)
    print("💡 Default: 8 (higher = rarer)")
    while True:
        try:
            val = input("Threshold (1-10, default 8): ").strip()
            if not val:
                RARITY_SCORE_THRESHOLD = 8
                print("✅ Using default 8")
                return 8
            val = int(val)
            if 1 <= val <= 10:
                RARITY_SCORE_THRESHOLD = val
                print(f"✅ Threshold set to {val}")
                return val
            else:
                print("❌ Enter 1-10")
        except:
            print("❌ Invalid input! Using default 8")
            RARITY_SCORE_THRESHOLD = 8
            return 8

# ==================== MAIN ====================
def main():
    global success_count, accounts_dict, save_thread_running, selected_region, base_name, base_password, account_count, RARITY_SCORE_THRESHOLD, RARE_COUNTER, COUPLES_COUNTER, fail_count, EXIT_FLAG

    # Fixed region VN
    selected_region = "VN"
    # Fixed defaults
    base_name = "WJXAZ"
    base_password = "TELE@WJXAZ"

    print("=" * 60)
    print("  STAR GUEST GENERATOR PRO")
    print("=" * 60)

    get_account_count()
    get_rarity_threshold()
    thread_count = get_thread_count()

    existing = load_region_accounts(selected_region)
    success_count = 0

    print("\n" + "=" * 60)
    print("  📊 SUMMARY")
    print("=" * 60)
    print(f"  Region: {selected_region} - {SUPPORTED_REGIONS[selected_region]}")
    print(f"  Base Name: {base_name}")
    print(f"  Base Password: {base_password}")
    print(f"  Target New Accounts: {account_count}")
    print(f"  Rarity Threshold: {RARITY_SCORE_THRESHOLD}+")
    print(f"  Threads: {thread_count}")
    print(f"  Existing Accounts in {selected_region}: {existing}")
    print("=" * 60)

    input("\nPress ENTER to start generating...")

    save_thread = threading.Thread(target=save_worker, daemon=True)
    save_thread.start()

    safe_print(f"🚀 Starting {thread_count} threads for region {selected_region}...\n")
    safe_print(f"📁 Accounts will be saved to: {ACCOUNTS_FOLDER}\n")

    start_time = time.time()
    threads = []
    for i in range(thread_count):
        t = threading.Thread(target=worker, args=(i, selected_region, base_name, base_password), daemon=True)
        t.start()
        threads.append(t)

    try:
        while not EXIT_FLAG:
            time.sleep(1)
            with success_lock:
                current = success_count
            progress = (current / account_count) * 100 if account_count > 0 else 0
            bar = '█' * int(40 * progress / 100) + '░' * (40 - int(40 * progress / 100))
            print(f"\r📊 Progress: {bar} {current}/{account_count} ({progress:.1f}%)", end="")
            if current >= account_count:
                break
    except KeyboardInterrupt:
        EXIT_FLAG = True
        print("\n\n⚠️ Stopping generation...")

    for t in threads:
        t.join(timeout=2)

    elapsed = time.time() - start_time

    print("\n\n" + "=" * 60)
    print("   📊 GENERATION SUMMARY")
    print("=" * 60)
    print(f"   ✅ New Accounts Generated: {success_count}")
    print(f"   ❌ Failed: {fail_count}")
    print(f"   💎 Rare Accounts: {RARE_COUNTER}")
    print(f"   💑 Couples: {COUPLES_COUNTER}")
    print(f"   ⏱️ Time: {elapsed:.2f} sec")
    print(f"   ⚡ Speed: {success_count/elapsed:.2f} acc/sec")
    total_all = sum(len(acc) for acc in accounts_dict.values())
    print(f"   📁 Total accounts now (including existing): {total_all}")
    print("=" * 60)

    print("\n💾 Saving final data...")
    save_all_regions()
    print("✅ Done! Check folders:")
    print(f"   📁 Normal: {ACCOUNTS_FOLDER}")

    save_thread_running = False
    save_queue.put(None)
    save_thread.join(timeout=2)

    print("\n✅ Generation completed. Press CTRL+C to exit.")
    while True:
        time.sleep(1)

if __name__ == '__main__':
    def start_system():
        try:
            main()
        except KeyboardInterrupt:
            print("\n\n⚠️ SYSTEM INTERRUPTED!")
            print("🔄 Auto-Restarting Script to ensure zero downtime...")
            save_all_regions()
            time.sleep(1)
            os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception as e:
            print(f"\n❌ CRITICAL CRASH DETECTED: {e}")
            print("\n🔄 Rebooting STAR system...")
            save_all_regions()
            time.sleep(2)
            os.execv(sys.executable, [sys.executable] + sys.argv)

    while True:
        start_system()