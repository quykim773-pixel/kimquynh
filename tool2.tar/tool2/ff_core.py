# -*- coding: utf-8 -*-
"""
HAKURA2 FREE FIRE PROTOCOL CORE ENGINE (REAL PROTOBUF & AES-CBC)
Handles:
- Real Player Profile Lookup via /GetPlayerPersonalShow (True Nickname, True Likes, Level, Region)
- Real Like Dispatcher via /LikeProfile
- Guest Account Generator & Dat Injector
"""

import os
import json
import time
import random
import string
import requests
import urllib.parse
import hmac
import hashlib
import asyncio
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TOKEN_CACHE_FILE = os.path.join(BASE_DIR, "token_cache.json")
ACCOUNTS_FILE = os.path.join(BASE_DIR, "accounts.json")

MAIN_KEY = b'Yg&tc%DEuh6%Zc^8'
MAIN_IV  = b'6oyZDr22E3ychjM%'

CLIENT_ID = "100067"
CLIENT_SECRET = "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3"

def encrypt_aes(data: bytes) -> bytes:
    cipher = AES.new(MAIN_KEY, AES.MODE_CBC, MAIN_IV)
    return cipher.encrypt(pad(data, 16))

def decrypt_aes(data: bytes) -> bytes:
    cipher = AES.new(MAIN_KEY, AES.MODE_CBC, MAIN_IV)
    return unpad(cipher.decrypt(data), 16)

def encode_varint(n: int) -> bytes:
    res = bytearray()
    while n > 0x7f:
        res.append((n & 0x7f) | 0x80)
        n >>= 7
    res.append(n)
    return bytes(res)

def pb_field(fn: int, val) -> bytes:
    if isinstance(val, int):
        return encode_varint((fn << 3) | 0) + encode_varint(val)
    elif isinstance(val, str):
        b = val.encode('utf-8')
        return encode_varint((fn << 3) | 2) + encode_varint(len(b)) + b
    elif isinstance(val, bytes):
        return encode_varint((fn << 3) | 2) + encode_varint(len(val)) + val
    return b''

def get_all_cached_sessions() -> list[dict]:
    """Lấy danh sách các session sắp xếp theo thời gian mới nhất, ưu tiên token còn hạn."""
    if not os.path.exists(TOKEN_CACHE_FILE):
        return []
    try:
        with open(TOKEN_CACHE_FILE, "r", encoding="utf-8") as f:
            cache = json.load(f)
        now = time.time()
        sessions = []
        for uid, data in cache.items():
            if isinstance(data, dict) and data.get("token"):
                data["account_id"] = data.get("account_id") or uid
                sessions.append(data)

        # Ưu tiên các session mới tạo (trong vòng 2.5 giờ) lên đầu
        sessions.sort(key=lambda s: s.get("cached_at", 0), reverse=True)
        return sessions
    except Exception as e:
        print(f"[get_all_cached_sessions error]: {e}")
        return []

def refresh_session_sync() -> dict | None:
    """Tự động đăng nhập lại tối đa 2 acc từ accounts.json để lấy token mới, tránh nghẽn thread."""
    try:
        if not os.path.exists(ACCOUNTS_FILE):
            return None
        with open(ACCOUNTS_FILE, "r", encoding="utf-8") as f:
            accs = json.load(f)
        if not accs:
            return None

        import login_engine
        # Thử ngược từ các acc mới nhất ở cuối danh sách
        for acc in reversed(accs[-3:]):
            uid = str(acc.get("uid", ""))
            pwd = str(acc.get("password", ""))
            if uid and pwd:
                try:
                    res = asyncio.run(asyncio.wait_for(login_engine.do_login(uid, pwd, "VN"), timeout=6.0))
                    if res and res.get("token"):
                        return res
                except Exception:
                    continue
    except Exception as e:
        print(f"[refresh_session_sync error]: {e}")
    return None

def query_player_profile(target_uid: int | str) -> dict:
    """
    Truy vấn thông tin hồ sơ THẬT 100% của người chơi từ máy chủ Garena:
    - Nickname (Tên nhân vật thật trong game)
    - Likes (Lượt thích thật hiển thị trong game)
    - Level (Cấp độ thật)
    - Region (Khu vực)
    """
    clean_uid = int(str(target_uid).strip())
    sessions = get_all_cached_sessions()
    
    # Nếu không có session hợp lệ, thử đăng nhập lại
    if not sessions:
        fresh = refresh_session_sync()
        if fresh:
            sessions = [fresh]
        else:
            return {"ok": False, "error": "Chưa có session hoạt động và không thể đăng nhập lại"}

    # Thử lần lượt các session từ mới đến cũ
    for session in sessions:
        token = session.get("token")
        server_url = session.get("server_url", "https://clientbp.ppmainecoonghj.com").rstrip("/")
        rel_ver = session.get("release_version", "OB55")

        req_pb = pb_field(1, clean_uid) + pb_field(2, 7) + pb_field(3, 1)
        enc_req = encrypt_aes(req_pb)

        headers = {
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 13; A063 Build/TKQ1.221220.001)",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Content-Type": "application/octet-stream",
            "Expect": "100-continue",
            "Authorization": f"Bearer {token}",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": rel_ver
        }

        url = f"{server_url}/GetPlayerPersonalShow"
        try:
            resp = requests.post(url, data=enc_req, headers=headers, timeout=12)
            if resp.status_code == 401:
                # Token hết hạn, thử session tiếp theo
                continue
            if resp.status_code != 200:
                continue

            from protobuf_decoder.protobuf_decoder import Parser
            parsed = Parser().parse(resp.content.hex())

            profile = {
                "ok": True,
                "uid": clean_uid,
                "nickname": f"FF_{clean_uid}",
                "likes": 0,
                "level": 1,
                "region": "VN",
                "exp": 0
            }

            for item in parsed:
                if item.field == 1 and hasattr(item.data, "results"):
                    for sub in item.data.results:
                        if sub.field == 3:  # Nickname
                            val = sub.data
                            if isinstance(val, str) and all(c in "0123456789abcdefABCDEF" for c in val) and len(val) % 2 == 0:
                                try:
                                    val = bytes.fromhex(val).decode("utf-8", errors="ignore")
                                except Exception:
                                    pass
                            profile["nickname"] = str(val)
                        elif sub.field == 5:  # Region
                            profile["region"] = str(sub.data)
                        elif sub.field == 6:  # Level
                            profile["level"] = int(sub.data)
                        elif sub.field == 7:  # Exp
                            profile["exp"] = int(sub.data)
                        elif sub.field == 21: # Real Like count
                            profile["likes"] = int(sub.data)

            return profile
        except Exception:
            continue

    # Nếu tất cả token đều 401, re-login một lần nữa
    fresh = refresh_session_sync()
    if fresh:
        return query_player_profile(target_uid)

    return {"ok": False, "error": "Tất cả session đều bị từ chối hoặc máy chủ không phản hồi"}


def send_like_to_target(target_uid: int | str, region: str = "VN") -> dict:
    """Gửi gói packet LikeProfile thật 100% đến máy chủ Garena cho từng tài khoản"""
    try:
        clean_uid = int(str(target_uid).strip())
    except ValueError:
        return {"ok": False, "error": "UID không hợp lệ"}

    sessions = get_all_cached_sessions()
    if not sessions:
        fresh = refresh_session_sync()
        if fresh:
            sessions = [fresh]
        else:
            return {"ok": False, "error": "Chưa có session đăng nhập"}

    # Field 1: UID as uint64 varint, Field 2: Region as string
    payload = pb_field(1, clean_uid) + pb_field(2, region)
    enc_payload = encrypt_aes(payload)

    # Chuẩn bị gói GetPlayerPersonalShow để mở hồ sơ trước khi bấm like
    req_view = pb_field(1, clean_uid) + pb_field(2, 7) + pb_field(3, 1)
    enc_view = encrypt_aes(req_view)

    sent_accounts = []
    for session in sessions:
        token = session.get("token")
        server_url = session.get("server_url", "https://clientbp.ppmainecoonghj.com").rstrip("/")
        rel_ver = session.get("release_version", "OB55")
        acc_name = session.get("name") or str(session.get("account_id", "Guest_Acc"))

        headers = {
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 14; Pixel 8 Build/UP1A.231005.007)",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Content-Type": "application/octet-stream",
            "Expect": "100-continue",
            "Authorization": f"Bearer {token}",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": rel_ver
        }

        # 1. Mở hồ sơ người chơi (GetPlayerPersonalShow)
        try:
            requests.post(f"{server_url}/GetPlayerPersonalShow", data=enc_view, headers=headers, timeout=6)
        except Exception:
            pass

        # 2. Bấm Like (LikeProfile)
        url = f"{server_url}/LikeProfile"
        status_ok = False
        try:
            resp = requests.post(url, data=enc_payload, headers=headers, timeout=8)
            if resp.status_code == 200:
                status_ok = True
        except Exception:
            pass

        sent_accounts.append({
            "name": acc_name,
            "uid": session.get("account_id"),
            "region": session.get("region", "VN"),
            "status": "200 OK" if status_ok else "Failed",
            "ok": status_ok
        })

    success_count = sum(1 for a in sent_accounts if a["ok"])
    return {
        "ok": success_count > 0,
        "likes_sent": success_count,
        "accounts": sent_accounts
    }


def send_visit_all(target_uid: int | str) -> dict:
    """
    Cho toàn bộ tài khoản trong kho đồng loạt gửi gói tin GetPlayerPersonalShow vào xem hồ sơ mục tiêu.
    Tên của các tài khoản sẽ hiển thị đầy đủ trong mục 'Khách ghé thăm gần đây' (Recent Visitors) in-game!
    """
    try:
        clean_uid = int(str(target_uid).strip())
    except ValueError:
        return {"ok": False, "error": "UID không hợp lệ!"}

    sessions = get_all_cached_sessions()
    if not sessions:
        fresh = refresh_session_sync()
        if fresh:
            sessions = [fresh]
        else:
            return {"ok": False, "error": "Chưa có tài khoản nào có session hợp lệ!"}

    # Truy vấn trước thông tin nick mục tiêu
    target_prof = query_player_profile(clean_uid)

    req_pb = pb_field(1, clean_uid) + pb_field(2, 7) + pb_field(3, 1)
    enc_req = encrypt_aes(req_pb)

    def _visit_single(s):
        tok = s.get("token")
        s_url = s.get("server_url", "https://clientbp.ppmainecoonghj.com").rstrip("/")
        name = s.get("name") or str(s.get("account_id", "Guest"))
        aid = s.get("account_id") or s.get("uid")
        rel_ver = s.get("release_version", "OB55")
        hdrs = {
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 13; A063 Build/TKQ1.221220.001)",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Content-Type": "application/octet-stream",
            "Expect": "100-continue",
            "Authorization": f"Bearer {tok}",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": rel_ver
        }
        try:
            r = requests.post(f"{s_url}/GetPlayerPersonalShow", data=enc_req, headers=hdrs, timeout=6)
            if r.status_code == 200:
                return {"name": name, "uid": aid, "ok": True, "status": "200 OK (Đã ghé thăm)"}
            elif r.status_code == 401:
                return {"name": name, "uid": aid, "ok": False, "status": "401 (Token hết hạn)"}
            else:
                return {"name": name, "uid": aid, "ok": False, "status": f"HTTP {r.status_code}"}
        except Exception as e:
            return {"name": name, "uid": aid, "ok": False, "status": f"Lỗi mạng: {e}"}

    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=10) as ex:
        results = list(ex.map(_visit_single, sessions))

    success = [r for r in results if r["ok"]]
    return {
        "ok": len(success) > 0,
        "target_profile": target_prof,
        "total_attempted": len(results),
        "total_success": len(success),
        "accounts": results
    }


def check_so_dep(account_id_str: int | str) -> tuple[bool, str | None]:
    """Kiểm tra xem ID nhân vật có phải số đẹp (Tứ quý, ngũ quý, sảnh tiến, tài lộc, số gánh) không"""
    aid = str(account_id_str)
    # 1. Ngũ quý / Lục quý / Tứ quý
    for d in "0123456789":
        if d * 5 in aid:
            return True, f"Ngũ quý {d * 5}"
        if d * 4 in aid:
            return True, f"Tứ quý {d * 4}"
    
    # 2. Sảnh tiến (12345, 23456, 56789, 6789, v.v.)
    sanh_tien = ["12345", "23456", "34567", "45678", "56789", "01234", "6789", "5678", "4567", "3456", "2345", "1234"]
    for s in sanh_tien:
        if s in aid:
            return True, f"Sảnh tiến {s}"
            
    # 3. Lặp tài lộc / Thần tài
    loc_phat = ["6868", "8686", "7979", "3939", "999", "888", "777"]
    for lp in loc_phat:
        if lp in aid:
            return True, f"Tài lộc / Thần tài {lp}"
            
    # 4. Gánh đảo / Soi gương
    for i in range(len(aid) - 4):
        sub = aid[i:i+5]
        if sub == sub[::-1]:
            return True, f"Số gánh {sub}"
            
    return False, None


def send_friend_request_single(session: dict, target_uid: int | str) -> tuple[bool, str]:
    """Gửi lời mời kết bạn từ 1 tài khoản tới mục tiêu"""
    try:
        from byte import Encrypt_ID, encrypt_api
        clean_uid = str(target_uid).strip()
        tok = session.get("token")
        s_url = session.get("server_url", "https://clientbp.ppmainecoonghj.com").rstrip("/")
        enc_id = Encrypt_ID(clean_uid)
        payload = f"08a7c4839f1e10{enc_id}1801"
        enc_payload = bytes.fromhex(encrypt_api(payload))
        headers = {
            "Expect": "100-continue",
            "Authorization": f"Bearer {tok}",
            "X-Unity-Version": "2018.4.11f1",
            "X-GA": "v1 1",
            "ReleaseVersion": session.get("release_version", "OB55"),
            "Content-Type": "application/octet-stream",
            "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 13; A063 Build/TKQ1.221220.001)",
            "Connection": "Keep-Alive"
        }
        r = requests.post(f"{s_url}/RequestAddingFriend", data=enc_payload, headers=headers, timeout=6)
        if r.status_code == 200:
            return True, "200 OK (Đã gửi lời mời)"
        elif r.status_code == 400:
            return False, "400 Đã có lời mời đang chờ hoặc đã là bạn bè"
        elif r.status_code == 401:
            return False, "401 Token hết hạn"
        else:
            return False, f"HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)


def spam_friend_requests_all(target_uid: int | str) -> dict:
    """Tất cả tài khoản trong kho đồng loạt gửi lời mời kết bạn (spam kết bạn) tới mục tiêu"""
    clean_uid = str(target_uid).strip()
    sessions = get_all_cached_sessions()
    if not sessions:
        return {"ok": False, "error": "Chưa có tài khoản nào có token hoạt động"}
    
    def _worker(s):
        name = s.get("name") or str(s.get("account_id", "Guest"))
        aid = s.get("account_id") or s.get("uid")
        ok, msg = send_friend_request_single(s, clean_uid)
        return {"name": name, "uid": aid, "ok": ok, "status": msg}

    from concurrent.futures import ThreadPoolExecutor
    with ThreadPoolExecutor(max_workers=10) as ex:
        results = list(ex.map(_worker, sessions))

    success = [r for r in results if r["ok"]]
    return {
        "ok": len(success) > 0,
        "total_attempted": len(results),
        "total_success": len(success),
        "accounts": results
    }


