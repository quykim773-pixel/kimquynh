#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HAKURA2 — AUTO FREE FIRE VN REG & LIKE ENGINE (AUTOMATED CLIENT PIPELINE)
========================================================================
Tự động hóa 100% quy trình:
1. Sinh acc khách Garena chính thức (OAuth).
2. Tự nạp vào guest100067.dat.
3. Tự động điều khiển game Free Fire qua ADB (vào sảnh, tạo tên, tìm UID & bấm Like).
4. Hoàn toàn tự động, người dùng không cần can thiệp thủ công.
========================================================================
"""

import os
import sys
import time
import json
import random
import string
import hashlib
import hmac
import urllib.parse
import subprocess
import requests

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CLIENT_ID = "100067"
CLIENT_SECRET = "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3"
URL_GUEST_REGISTER = "https://connect.garena.com/oauth/guest/register"

ANDROID_GUEST_FILES = [
    "/storage/emulated/0/Android/media/com.dts.freefireth/guest100067.dat",
    "/storage/emulated/0/Android/media/com.dts.freefiremax/guest100067.dat",
    "/storage/emulated/0/Android/media/guest100067.dat",
    "/storage/emulated/0/Android/data/com.dts.freefireth/files/guest100067.dat",
    "/storage/emulated/0/Android/data/com.dts.freefiremax/files/guest100067.dat",
    os.path.join(BASE_DIR, "guest100067.dat"),
]

def log(msg):
    now = time.strftime("%H:%M:%S")
    print(f"[{now}] {msg}")

def run_adb(cmd):
    """Chạy lệnh ADB shell"""
    try:
        full_cmd = f"adb {cmd}"
        res = subprocess.run(full_cmd, shell=True, capture_output=True, text=True, timeout=10)
        return res.stdout.strip()
    except Exception as e:
        return ""

def create_oauth_guest():
    """Tạo tài khoản khách Garena chính thống"""
    try:
        raw_password = str(random.randint(1000000000, 9999999999))
        pass_hash = hashlib.sha256(raw_password.encode("utf-8")).hexdigest().upper()

        reg_params = {
            "password": pass_hash,
            "client_type": "2",
            "source": "2",
            "app_id": CLIENT_ID
        }
        encoded_params = urllib.parse.urlencode(reg_params)
        signature = hmac.new(
            CLIENT_SECRET.encode("utf-8"),
            encoded_params.encode("utf-8"),
            hashlib.sha256
        ).hexdigest()

        headers = {
            "User-Agent": "GarenaMSDK/4.0.19P10(I2404 ;Android 15;vi;VN;)",
            "Connection": "Keep-Alive",
            "Accept-Encoding": "gzip",
            "Content-Type": "application/x-www-form-urlencoded",
            "Authorization": f"Signature {signature}"
        }

        resp = requests.post(URL_GUEST_REGISTER, data=encoded_params, headers=headers, timeout=12)
        if resp.status_code == 200:
            data = resp.json()
            garena_uid = data.get("uid")
            if garena_uid:
                inject_guest_file(garena_uid, pass_hash)
                return {
                    "uid": str(garena_uid),
                    "password": pass_hash,
                    "raw_password": raw_password
                }
    except Exception as e:
        log(f"Lỗi tạo tài khoản: {e}")
    return None

def inject_guest_file(garena_uid, pass_hash):
    payload = json.dumps({
        "guest_account_info": {
            "uid": int(garena_uid),
            "password": str(pass_hash)
        }
    })
    for path in ANDROID_GUEST_FILES:
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                f.write(payload)
        except Exception:
            pass

from ff_core import query_player_profile, send_like_to_target

def auto_cycle_account_and_like(target_uid: str, ff_package="com.dts.freefireth"):
    """
    Quy trình tự động hoàn chỉnh:
    1. Kiểm tra hồ sơ mục tiêu trước (Tên, Level, Like ban đầu)
    2. Tạo acc khách mới qua OAuth & nạp vào guest100067.dat
    3. Mở game Free Fire nạp sảnh
    4. Bấm Like qua ADB Client / Gửi gói tin LikeProfile
    5. Kiểm tra hồ sơ sau khi like & đo lường số like tăng
    """
    target_uid = str(target_uid).strip()
    log("=" * 60)
    log(f"🚀 BẮT ĐẦU QUY TRÌNH TỰ ĐỘNG THẢ LIKE CHO MỤC TIÊU: {target_uid}")
    log("=" * 60)

    # 1. Truy vấn profile mục tiêu trước
    prof_before = query_player_profile(target_uid)
    name = prof_before.get("nickname", f"Player_{target_uid}") if prof_before.get("ok") else f"Player_{target_uid}"
    likes_before = prof_before.get("likes", 0) if prof_before.get("ok") else 0
    region = prof_before.get("region", "VN") if prof_before.get("ok") else "VN"
    level = prof_before.get("level", 1) if prof_before.get("ok") else 1

    # 2. Tạo acc khách mới
    log("1️⃣ Đang sinh tài khoản khách Garena VN mới qua OAuth...")
    acc = create_oauth_guest()
    if not acc:
        log("❌ Không thể tạo tài khoản khách. Dừng quy trình.")
        return {
            "ok": False,
            "error": "Không thể tạo tài khoản khách OAuth"
        }
    guest_uid = acc['uid']
    log(f"✅ Đã tạo Garena UID: {guest_uid}")

    # 3. Khởi động game nạp file khách
    log(f"2️⃣ Khởi động game Free Fire ({ff_package})...")
    run_adb(f"shell am force-stop {ff_package}")
    run_adb(f"shell monkey -p {ff_package} 1")
    try:
        os.system(f"/data/data/com.termux/files/usr/bin/am start -n {ff_package}/com.dts.freefireth.FFMainActivity >/dev/null 2>&1")
    except Exception:
        pass

    # 4. Tự động click qua ADB nếu có thiết bị
    devices = run_adb("devices")
    has_device = "device\n" in devices or devices.endswith("device")
    if has_device:
        log("⏳ Đang điều khiển game qua ADB vào sảnh...")
        time.sleep(12)
        run_adb("shell input tap 540 1850")  # Khách
        time.sleep(4)
        run_adb("shell input tap 540 1200")  # Chạm vào sảnh
        time.sleep(5)
        run_adb("shell input tap 540 1400")  # Đặt tên nếu có
        time.sleep(4)
        run_adb("shell input tap 980 150")   # Bạn bè
        time.sleep(2)
        run_adb("shell input tap 300 350")   # Thêm bạn
        time.sleep(2)
        run_adb("shell input tap 500 250")   # Nhập UID
        time.sleep(1)
        run_adb(f"shell input text {target_uid}")
        time.sleep(1)
        run_adb("shell input keyevent 66")   # Enter
        time.sleep(2)
        run_adb("shell input tap 500 450")   # Chọn nick
        time.sleep(2)
        run_adb("shell input tap 850 400")   # Bấm Like
        time.sleep(2)

    # 5. Gửi thêm packet LikeProfile trực tiếp từ cổng socket
    log("5️⃣ Gửi packet LikeProfile trực tiếp lên máy chủ Garena...")
    send_like_to_target(target_uid, region)
    time.sleep(1.5)

    # 6. Kiểm tra lại profile sau khi like
    prof_after = query_player_profile(target_uid)
    likes_after = prof_after.get("likes", likes_before) if prof_after.get("ok") else likes_before
    diff = likes_after - likes_before

    log(f"🎉 HOÀN TẤT: Nick: {name} | Like trước: {likes_before} | Like sau: {likes_after} (+{diff})")
    return {
        "ok": True,
        "guest_uid": guest_uid,
        "target_uid": target_uid,
        "target_name": name,
        "level": level,
        "region": region,
        "likes_before": likes_before,
        "likes_after": likes_after,
        "diff": diff
    }

if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "15162700166"
    auto_cycle_account_and_like(target)
